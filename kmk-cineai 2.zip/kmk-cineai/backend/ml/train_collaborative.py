"""
Standalone script to validate the collaborative filtering (SVD) model
against the current ratings table. The live API fits this in-memory
(see app/services/recommender.py) — use this for offline sanity checks.

Run from backend/:  python ml/train_collaborative.py
"""
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.database import SessionLocal
from app import models
from app.services.collaborative_model import CollaborativeModel


def main():
    db = SessionLocal()
    ratings = db.query(models.Rating).all()
    if len(ratings) < 5:
        print(f"Only {len(ratings)} ratings found — need at least 5. Run `python seed.py` first.")
        return

    model = CollaborativeModel()
    model.fit(ratings)
    print(f"Fitted SVD collaborative model on {len(ratings)} ratings "
          f"({len(model.user_ids)} users x {len(model.movie_ids)} movies).")

    sample_user = model.user_ids[0]
    by_id = {m.id: m for m in db.query(models.Movie).all()}
    rated_movie_ids = {r.movie_id for r in ratings if r.user_id == sample_user}
    recs = model.recommend_for_user(sample_user, exclude_movie_ids=rated_movie_ids, top_k=5)
    print(f"\nTop predicted movies for user_id={sample_user}:")
    for mid, score in recs:
        print(f"  {by_id[mid].title:40s} predicted={score:.2f}")
    db.close()


if __name__ == "__main__":
    main()
