"""
Computes semantic embeddings for every movie and stores them in the
MovieEmbedding table (JSON-encoded). Requires the optional
sentence-transformers dependency; if it's not installed, this script
explains how to enable it and exits cleanly (the API still works via
the TF-IDF fallback in app/services/semantic_model.py).

Run from backend/:  python ml/train_embeddings.py
"""
import sys, os, json
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.database import SessionLocal
from app import models


def main():
    try:
        from sentence_transformers import SentenceTransformer
    except ImportError:
        print(
            "sentence-transformers is not installed.\n"
            "Install it with: pip install sentence-transformers --break-system-packages\n"
            "(it's commented out of requirements.txt by default to keep the base app light)\n"
            "The API will keep working using the TF-IDF fallback in the meantime."
        )
        return

    db = SessionLocal()
    movies = db.query(models.Movie).all()
    if not movies:
        print("No movies found — run `python seed.py` first.")
        return

    model = SentenceTransformer("all-MiniLM-L6-v2")
    texts = [f"{m.title}. {m.overview or ''} Genres: {m.genres or ''}" for m in movies]
    embeddings = model.encode(texts, normalize_embeddings=True)

    db.query(models.MovieEmbedding).delete()
    for movie, vec in zip(movies, embeddings):
        db.add(models.MovieEmbedding(movie_id=movie.id, embedding=json.dumps(vec.tolist())))
    db.commit()
    print(f"Stored semantic embeddings for {len(movies)} movies.")
    db.close()


if __name__ == "__main__":
    main()
