"""
Standalone script to validate/inspect the content-based TF-IDF model.
The live API fits this model in-memory on startup/refresh (see
app/services/recommender.py) — this script is for offline testing,
e.g. checking what "Inception" is most similar to before shipping.

Run from backend/:  python ml/train_content.py
"""
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.database import SessionLocal
from app import models
from app.services.content_model import ContentModel


def main():
    db = SessionLocal()
    movies = db.query(models.Movie).all()
    if not movies:
        print("No movies found — run `python seed.py` first.")
        return
    model = ContentModel()
    model.fit(movies)
    by_id = {m.id: m for m in movies}

    sample = movies[0]
    print(f"Content-based model fit on {len(movies)} movies.")
    print(f"\nTop similar movies to '{sample.title}':")
    for mid, score in model.similar_to(sample.id, top_k=5):
        print(f"  {by_id[mid].title:40s} score={score:.3f}")
    db.close()


if __name__ == "__main__":
    main()
