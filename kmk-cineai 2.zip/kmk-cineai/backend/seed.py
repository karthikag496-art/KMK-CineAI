"""
Seeds the local SQLite database with demo movies, a demo user account,
and a handful of ratings so recommendation/collaborative-filtering
endpoints have something to work with immediately after setup.

Run:
    python seed.py
"""
import random
from app.database import SessionLocal, Base, engine
from app import models, auth
from movie_data import MOVIES

random.seed(7)

DEMO_USERS = [
    {"username": "demo_user", "email": "demo@kmkcineai.com", "password": "Demo@1234"},
    {"username": "ashwin_r", "email": "ashwin@kmkcineai.com", "password": "Demo@1234"},
    {"username": "priya_k", "email": "priya@kmkcineai.com", "password": "Demo@1234"},
]


def seed():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        # ---- Movies ----
        movie_objs = []
        for m in MOVIES:
            movie = models.Movie(**m)
            db.add(movie)
            movie_objs.append(movie)
        db.commit()
        for m in movie_objs:
            db.refresh(m)
        print(f"Seeded {len(movie_objs)} movies.")

        # ---- Users ----
        user_objs = []
        for u in DEMO_USERS:
            user = models.User(
                username=u["username"],
                email=u["email"],
                password_hash=auth.hash_password(u["password"]),
                onboarded=1,
            )
            db.add(user)
            user_objs.append(user)
        db.commit()
        for u in user_objs:
            db.refresh(u)
        print(f"Seeded {len(user_objs)} demo users (password for all: Demo@1234).")

        # ---- Preferences (for onboarding/cold-start demo) ----
        db.add(models.UserPreference(user_id=user_objs[0].id, kind="genre", value="Action"))
        db.add(models.UserPreference(user_id=user_objs[0].id, kind="genre", value="Thriller"))
        db.add(models.UserPreference(user_id=user_objs[0].id, kind="language", value="Tamil"))
        db.add(models.UserPreference(user_id=user_objs[1].id, kind="genre", value="Sci-Fi"))
        db.add(models.UserPreference(user_id=user_objs[1].id, kind="genre", value="Fantasy"))
        db.add(models.UserPreference(user_id=user_objs[2].id, kind="genre", value="Romantic"))
        db.add(models.UserPreference(user_id=user_objs[2].id, kind="genre", value="Anime"))
        db.commit()

        # ---- Ratings (random-ish but biased by preference so collaborative
        #      filtering has real signal to learn from) ----
        rating_count = 0
        for user in user_objs:
            prefs = {p.value for p in db.query(models.UserPreference).filter_by(user_id=user.id, kind="genre")}
            sample_size = min(len(movie_objs), random.randint(12, 20))
            sampled = random.sample(movie_objs, sample_size)
            for movie in sampled:
                movie_genres = set(g.strip() for g in movie.genres.split(","))
                base = 4.2 if movie_genres & prefs else random.uniform(2.5, 4.0)
                rating_val = round(min(5.0, max(0.5, base + random.uniform(-0.5, 0.5))) * 2) / 2
                db.add(models.Rating(user_id=user.id, movie_id=movie.id, rating=rating_val))
                rating_count += 1
        db.commit()
        print(f"Seeded {rating_count} ratings.")

        # ---- Recompute movie aggregate ratings from seeded ratings ----
        for movie in movie_objs:
            ratings = db.query(models.Rating).filter(models.Rating.movie_id == movie.id).all()
            if ratings:
                movie.rating = round(sum(r.rating for r in ratings) / len(ratings), 2)
                movie.vote_count = len(ratings)
        db.commit()

        # ---- A few watchlist entries ----
        for user in user_objs:
            picks = random.sample(movie_objs, 4)
            for movie in picks:
                db.add(models.WatchlistItem(user_id=user.id, movie_id=movie.id))
        db.commit()
        print("Seeded watchlists.")

        print("\nDemo login credentials:")
        for u in DEMO_USERS:
            print(f"  email: {u['email']}   password: {u['password']}")

    finally:
        db.close()


if __name__ == "__main__":
    seed()
