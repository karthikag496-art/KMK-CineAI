from typing import List, Optional
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app import models, schemas, auth
from app.services.recommender import engine

router = APIRouter(prefix="/recommendations", tags=["recommendations"])


@router.get("/", response_model=List[schemas.ScoredMovie])
def get_recommendations(
    limit: int = 20,
    db: Session = Depends(get_db),
    user: Optional[models.User] = Depends(auth.get_optional_user),
):
    engine.refresh(db)
    results = engine.recommend_for_user(db, user, top_k=limit)
    return [
        schemas.ScoredMovie(**schemas.MovieOut.model_validate(r["movie"]).model_dump(), score=r["score"], reason=r["reason"])
        for r in results
    ]


@router.get("/because-you-liked")
def because_you_liked(
    db: Session = Depends(get_db),
    user: models.User = Depends(auth.get_current_user),
):
    engine.refresh(db)
    anchor, recs = engine.because_you_liked(db, user, top_k=10)
    if not anchor:
        return {"anchor": None, "recommendations": []}
    return {
        "anchor": schemas.MovieOut.model_validate(anchor),
        "recommendations": [
            {**schemas.MovieOut.model_validate(r["movie"]).model_dump(), "score": r["score"], "reason": r["reason"]}
            for r in recs
        ],
    }


@router.post("/onboarding")
def submit_onboarding(
    payload: schemas.OnboardingRequest,
    db: Session = Depends(get_db),
    user: models.User = Depends(auth.get_current_user),
):
    db.query(models.UserPreference).filter(models.UserPreference.user_id == user.id).delete()
    for g in payload.genres:
        db.add(models.UserPreference(user_id=user.id, kind="genre", value=g))
    for lang in payload.languages:
        db.add(models.UserPreference(user_id=user.id, kind="language", value=lang))
    for a in payload.actors:
        db.add(models.UserPreference(user_id=user.id, kind="actor", value=a))
    user.onboarded = 1
    db.commit()
    engine.mark_dirty()
    return {"status": "ok"}
