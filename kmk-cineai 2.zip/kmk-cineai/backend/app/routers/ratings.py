from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app import models, schemas, auth
from app.services.recommender import engine

router = APIRouter(tags=["ratings"])


def _recompute_movie_rating(db: Session, movie_id: int):
    movie = db.query(models.Movie).filter(models.Movie.id == movie_id).first()
    ratings = db.query(models.Rating).filter(models.Rating.movie_id == movie_id).all()
    if ratings:
        movie.rating = round(sum(r.rating for r in ratings) / len(ratings), 2)
        movie.vote_count = len(ratings)
    db.commit()


@router.post("/movies/{movie_id}/rating", response_model=schemas.RatingOut)
def rate_movie(
    movie_id: int,
    payload: schemas.RatingCreate,
    db: Session = Depends(get_db),
    user: models.User = Depends(auth.get_current_user),
):
    movie = db.query(models.Movie).filter(models.Movie.id == movie_id).first()
    if not movie:
        raise HTTPException(status_code=404, detail="Movie not found.")

    existing = (
        db.query(models.Rating)
        .filter(models.Rating.user_id == user.id, models.Rating.movie_id == movie_id)
        .first()
    )
    if existing:
        existing.rating = payload.rating
        rating_obj = existing
    else:
        rating_obj = models.Rating(user_id=user.id, movie_id=movie_id, rating=payload.rating)
        db.add(rating_obj)

    db.commit()
    db.refresh(rating_obj)
    _recompute_movie_rating(db, movie_id)
    engine.mark_dirty()
    return rating_obj


@router.get("/users/me/ratings", response_model=List[schemas.RatingOut])
def my_ratings(db: Session = Depends(get_db), user: models.User = Depends(auth.get_current_user)):
    return (
        db.query(models.Rating)
        .filter(models.Rating.user_id == user.id)
        .order_by(models.Rating.created_at.desc())
        .all()
    )


@router.delete("/movies/{movie_id}/rating")
def delete_rating(movie_id: int, db: Session = Depends(get_db), user: models.User = Depends(auth.get_current_user)):
    rating_obj = (
        db.query(models.Rating)
        .filter(models.Rating.user_id == user.id, models.Rating.movie_id == movie_id)
        .first()
    )
    if not rating_obj:
        raise HTTPException(status_code=404, detail="Rating not found.")
    db.delete(rating_obj)
    db.commit()
    _recompute_movie_rating(db, movie_id)
    engine.mark_dirty()
    return {"status": "deleted"}
