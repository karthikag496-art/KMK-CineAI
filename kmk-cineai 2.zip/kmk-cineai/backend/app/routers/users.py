from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app import models, schemas, auth
from app.services.recommender import engine

router = APIRouter(tags=["users"])


@router.get("/users/me", response_model=schemas.UserOut)
def get_profile(user: models.User = Depends(auth.get_current_user)):
    return user


# ---- Basic admin-style movie management (any logged-in user for this demo;
#      swap `auth.get_current_user` for a role-checked dependency in prod) ----

@router.post("/admin/movies", response_model=schemas.MovieOut, status_code=201)
def admin_create_movie(
    payload: schemas.MovieCreate,
    db: Session = Depends(get_db),
    user: models.User = Depends(auth.get_current_user),
):
    movie = models.Movie(**payload.model_dump())
    db.add(movie)
    db.commit()
    db.refresh(movie)
    engine.mark_dirty()
    return movie


@router.put("/admin/movies/{movie_id}", response_model=schemas.MovieOut)
def admin_update_movie(
    movie_id: int,
    payload: schemas.MovieUpdate,
    db: Session = Depends(get_db),
    user: models.User = Depends(auth.get_current_user),
):
    movie = db.query(models.Movie).filter(models.Movie.id == movie_id).first()
    if not movie:
        raise HTTPException(status_code=404, detail="Movie not found.")
    for k, v in payload.model_dump(exclude_unset=True).items():
        setattr(movie, k, v)
    db.commit()
    db.refresh(movie)
    engine.mark_dirty()
    return movie


@router.delete("/admin/movies/{movie_id}")
def admin_delete_movie(
    movie_id: int,
    db: Session = Depends(get_db),
    user: models.User = Depends(auth.get_current_user),
):
    movie = db.query(models.Movie).filter(models.Movie.id == movie_id).first()
    if not movie:
        raise HTTPException(status_code=404, detail="Movie not found.")
    db.delete(movie)
    db.commit()
    engine.mark_dirty()
    return {"status": "deleted"}
