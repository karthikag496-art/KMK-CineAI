from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import or_

from app.database import get_db
from app import models, schemas
from app.services.recommender import engine

router = APIRouter(tags=["movies"])

ALL_GENRES = [
    "Horror", "Love", "Romantic", "Thriller", "Historical", "Marvel", "Anime",
    "C-Drama", "K-Pop", "Action", "Comedy", "Drama", "Sci-Fi", "Fantasy",
    "Crime", "Adventure",
]


def _get_engine(db: Session):
    engine.refresh(db)
    return engine


@router.get("/movies/", response_model=List[schemas.MovieOut])
def list_movies(
    genre: Optional[str] = None,
    language: Optional[str] = None,
    year: Optional[int] = None,
    min_rating: Optional[float] = None,
    sort: str = Query("trending", pattern="^(trending|popularity|rating|latest|az)$"),
    limit: int = 40,
    offset: int = 0,
    db: Session = Depends(get_db),
):
    q = db.query(models.Movie)
    if genre:
        q = q.filter(models.Movie.genres.ilike(f"%{genre}%"))
    if language:
        q = q.filter(models.Movie.language.ilike(f"%{language}%"))
    if year:
        q = q.filter(models.Movie.release_year == year)
    if min_rating:
        q = q.filter(models.Movie.rating >= min_rating)

    if sort == "rating":
        q = q.order_by(models.Movie.rating.desc())
    elif sort == "latest":
        q = q.order_by(models.Movie.release_year.desc())
    elif sort == "az":
        q = q.order_by(models.Movie.title.asc())
    else:  # trending / popularity
        q = q.order_by(models.Movie.popularity.desc())

    return q.offset(offset).limit(limit).all()


@router.get("/movies/search", response_model=List[schemas.ScoredMovie])
def search_movies(q: str = Query(..., min_length=1), limit: int = 24, db: Session = Depends(get_db)):
    like = f"%{q}%"
    sql_matches = (
        db.query(models.Movie)
        .filter(
            or_(
                models.Movie.title.ilike(like),
                models.Movie.cast.ilike(like),
                models.Movie.actresses.ilike(like),
                models.Movie.director.ilike(like),
                models.Movie.music_director.ilike(like),
                models.Movie.genres.ilike(like),
                models.Movie.language.ilike(like),
            )
        )
        .all()
    )
    eng = _get_engine(db)
    candidate_ids = [m.id for m in sql_matches] or [m.id for m in db.query(models.Movie).all()]
    ranked = eng.search_rank(q, candidate_ids, top_k=limit)
    return [
        schemas.ScoredMovie(**schemas.MovieOut.model_validate(r["movie"]).model_dump(), score=r["score"], reason=r["reason"])
        for r in ranked
    ]


@router.get("/genres")
def list_genres():
    return ALL_GENRES


@router.get("/movies/{movie_id}", response_model=schemas.MovieOut)
def get_movie(movie_id: int, db: Session = Depends(get_db)):
    movie = db.query(models.Movie).filter(models.Movie.id == movie_id).first()
    if not movie:
        raise HTTPException(status_code=404, detail="Movie not found.")
    return movie


@router.get("/movies/{movie_id}/related", response_model=List[schemas.ScoredMovie])
def related_movies(movie_id: int, limit: int = 12, db: Session = Depends(get_db)):
    movie = db.query(models.Movie).filter(models.Movie.id == movie_id).first()
    if not movie:
        raise HTTPException(status_code=404, detail="Movie not found.")
    eng = _get_engine(db)
    results = eng.related_to(movie_id, top_k=limit)
    return [
        schemas.ScoredMovie(**schemas.MovieOut.model_validate(r["movie"]).model_dump(), score=r["score"], reason=r["reason"])
        for r in results
    ]


@router.get("/movies/{movie_id}/recommendations", response_model=List[schemas.ScoredMovie])
def movie_recommendations(movie_id: int, limit: int = 12, db: Session = Depends(get_db)):
    # Alias of "related" at the single-movie level, kept as a distinct endpoint
    # per spec (e.g. could diverge to use collaborative "users who liked X also liked Y").
    return related_movies(movie_id, limit=limit, db=db)


def _people_field_query(field, name: str, db: Session):
    return db.query(models.Movie).filter(field.ilike(f"%{name}%")).all()


@router.get("/actors/{actor_name}")
def actor_profile(actor_name: str, db: Session = Depends(get_db)):
    movies = _people_field_query(models.Movie.cast, actor_name, db)
    if not movies:
        raise HTTPException(status_code=404, detail="Actor not found.")
    return {
        "name": actor_name,
        "movies": [schemas.MovieOut.model_validate(m) for m in movies],
        "popular": sorted(movies, key=lambda m: m.popularity, reverse=True)[:6],
        "highest_rated": sorted(movies, key=lambda m: m.rating, reverse=True)[:6],
    }


@router.get("/actresses/{actress_name}")
def actress_profile(actress_name: str, db: Session = Depends(get_db)):
    movies = _people_field_query(models.Movie.actresses, actress_name, db)
    if not movies:
        raise HTTPException(status_code=404, detail="Actress not found.")
    return {
        "name": actress_name,
        "movies": [schemas.MovieOut.model_validate(m) for m in movies],
        "popular": sorted(movies, key=lambda m: m.popularity, reverse=True)[:6],
        "highest_rated": sorted(movies, key=lambda m: m.rating, reverse=True)[:6],
    }


@router.get("/directors/{director_name}")
def director_profile(director_name: str, db: Session = Depends(get_db)):
    movies = _people_field_query(models.Movie.director, director_name, db)
    if not movies:
        raise HTTPException(status_code=404, detail="Director not found.")
    return {
        "name": director_name,
        "movies": [schemas.MovieOut.model_validate(m) for m in movies],
    }


@router.get("/music-directors/{name}")
def music_director_profile(name: str, db: Session = Depends(get_db)):
    movies = _people_field_query(models.Movie.music_director, name, db)
    if not movies:
        raise HTTPException(status_code=404, detail="Music director not found.")
    return {
        "name": name,
        "movies": [schemas.MovieOut.model_validate(m) for m in movies],
    }
