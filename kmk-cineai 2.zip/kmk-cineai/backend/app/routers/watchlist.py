from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app import models, schemas, auth

router = APIRouter(tags=["watchlist"])


@router.post("/watchlist/{movie_id}", response_model=schemas.WatchlistOut, status_code=201)
def add_to_watchlist(movie_id: int, db: Session = Depends(get_db), user: models.User = Depends(auth.get_current_user)):
    movie = db.query(models.Movie).filter(models.Movie.id == movie_id).first()
    if not movie:
        raise HTTPException(status_code=404, detail="Movie not found.")

    existing = (
        db.query(models.WatchlistItem)
        .filter(models.WatchlistItem.user_id == user.id, models.WatchlistItem.movie_id == movie_id)
        .first()
    )
    if existing:
        return existing

    item = models.WatchlistItem(user_id=user.id, movie_id=movie_id)
    db.add(item)
    db.commit()
    db.refresh(item)
    return item


@router.delete("/watchlist/{movie_id}")
def remove_from_watchlist(movie_id: int, db: Session = Depends(get_db), user: models.User = Depends(auth.get_current_user)):
    item = (
        db.query(models.WatchlistItem)
        .filter(models.WatchlistItem.user_id == user.id, models.WatchlistItem.movie_id == movie_id)
        .first()
    )
    if not item:
        raise HTTPException(status_code=404, detail="Not in watchlist.")
    db.delete(item)
    db.commit()
    return {"status": "removed"}


@router.get("/watchlist", response_model=List[schemas.WatchlistOut])
def get_watchlist(db: Session = Depends(get_db), user: models.User = Depends(auth.get_current_user)):
    return (
        db.query(models.WatchlistItem)
        .filter(models.WatchlistItem.user_id == user.id)
        .order_by(models.WatchlistItem.created_at.desc())
        .all()
    )
