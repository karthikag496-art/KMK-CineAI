from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, EmailStr, Field


# ---------- Auth ----------

class UserCreate(BaseModel):
    username: str = Field(min_length=3, max_length=64)
    email: EmailStr
    password: str = Field(min_length=6, max_length=128)


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserOut(BaseModel):
    id: int
    username: str
    email: str
    onboarded: int

    class Config:
        from_attributes = True


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


# ---------- Movies ----------

class MovieOut(BaseModel):
    id: int
    title: str
    overview: str
    genres: str
    cast: str
    actresses: str
    director: str
    music_director: str
    writer: str
    producer: str
    language: str
    release_year: int
    release_date: str
    duration: int
    poster_url: str
    backdrop_url: str
    rating: float
    vote_count: int
    popularity: float

    class Config:
        from_attributes = True


class MovieCreate(BaseModel):
    title: str
    overview: str = ""
    genres: str = ""
    cast: str = ""
    actresses: str = ""
    director: str = ""
    music_director: str = ""
    writer: str = ""
    producer: str = ""
    language: str = ""
    release_year: int = 2020
    release_date: str = ""
    duration: int = 120
    poster_url: str = ""
    backdrop_url: str = ""


class MovieUpdate(BaseModel):
    title: Optional[str] = None
    overview: Optional[str] = None
    genres: Optional[str] = None
    cast: Optional[str] = None
    actresses: Optional[str] = None
    director: Optional[str] = None
    music_director: Optional[str] = None
    writer: Optional[str] = None
    producer: Optional[str] = None
    language: Optional[str] = None
    release_year: Optional[int] = None
    release_date: Optional[str] = None
    duration: Optional[int] = None
    poster_url: Optional[str] = None
    backdrop_url: Optional[str] = None


class ScoredMovie(MovieOut):
    score: float = 0.0
    reason: str = ""


# ---------- Ratings ----------

class RatingCreate(BaseModel):
    rating: float = Field(ge=0.5, le=5.0)


class RatingOut(BaseModel):
    id: int
    movie_id: int
    rating: float
    created_at: datetime
    movie: MovieOut

    class Config:
        from_attributes = True


# ---------- Watchlist ----------

class WatchlistOut(BaseModel):
    id: int
    movie_id: int
    created_at: datetime
    movie: MovieOut

    class Config:
        from_attributes = True


# ---------- Preferences / Onboarding ----------

class OnboardingRequest(BaseModel):
    genres: List[str] = []
    languages: List[str] = []
    actors: List[str] = []
