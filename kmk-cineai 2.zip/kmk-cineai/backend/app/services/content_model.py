"""
Content-based recommendation model.

Builds a combined text representation per movie (title + overview + genres +
cast + director + language), vectorizes it with TF-IDF, and exposes cosine
similarity lookups. This is intentionally dependency-light (scikit-learn only)
so the app works even when heavier optional ML packages are not installed.
"""
from __future__ import annotations
from typing import List, Tuple
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


def _combined_text(m) -> str:
    parts = [
        (m.title or "") + " " + (m.title or ""),  # weight title a bit higher
        m.overview or "",
        (m.genres or "").replace(",", " "),
        (m.cast or "").replace(",", " "),
        (m.actresses or "").replace(",", " "),
        m.director or "",
        m.music_director or "",
        m.language or "",
    ]
    return " ".join(parts).lower()


class ContentModel:
    def __init__(self):
        self.movie_ids: List[int] = []
        self.vectorizer: TfidfVectorizer | None = None
        self.matrix = None
        self.sim = None

    def fit(self, movies: list):
        self.movie_ids = [m.id for m in movies]
        texts = [_combined_text(m) for m in movies]
        self.vectorizer = TfidfVectorizer(
            stop_words="english", max_features=20000, ngram_range=(1, 2)
        )
        if not texts:
            self.matrix = None
            self.sim = None
            return
        self.matrix = self.vectorizer.fit_transform(texts)
        self.sim = cosine_similarity(self.matrix)

    def _idx(self, movie_id: int) -> int | None:
        try:
            return self.movie_ids.index(movie_id)
        except ValueError:
            return None

    def similar_to(self, movie_id: int, top_k: int = 12) -> List[Tuple[int, float]]:
        if self.sim is None:
            return []
        idx = self._idx(movie_id)
        if idx is None:
            return []
        scores = list(enumerate(self.sim[idx]))
        scores = [(i, s) for i, s in scores if i != idx]
        scores.sort(key=lambda x: x[1], reverse=True)
        return [(self.movie_ids[i], float(s)) for i, s in scores[:top_k]]

    def similar_to_text(self, query: str, top_k: int = 20) -> List[Tuple[int, float]]:
        """Score all movies against an arbitrary free-text query (used for search)."""
        if self.vectorizer is None or self.matrix is None:
            return []
        q_vec = self.vectorizer.transform([query.lower()])
        scores = cosine_similarity(q_vec, self.matrix).flatten()
        order = np.argsort(scores)[::-1][:top_k]
        return [(self.movie_ids[i], float(scores[i])) for i in order if scores[i] > 0]

    def profile_similarity(self, liked_movie_ids: List[int], top_k: int = 20) -> List[Tuple[int, float]]:
        """Average the TF-IDF vectors of a user's liked movies to build a taste
        profile, then rank all other movies against it."""
        if self.matrix is None:
            return []
        idxs = [self._idx(mid) for mid in liked_movie_ids]
        idxs = [i for i in idxs if i is not None]
        if not idxs:
            return []
        profile_vec = self.matrix[idxs].mean(axis=0)
        profile_vec = np.asarray(profile_vec)
        scores = cosine_similarity(profile_vec, self.matrix).flatten()
        order = np.argsort(scores)[::-1]
        results = []
        for i in order:
            mid = self.movie_ids[i]
            if mid in liked_movie_ids:
                continue
            if scores[i] <= 0:
                continue
            results.append((mid, float(scores[i])))
            if len(results) >= top_k:
                break
        return results
