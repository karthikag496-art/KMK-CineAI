"""
Semantic similarity model.

Tries to use sentence-transformers (all-MiniLM-L6-v2) for true semantic
embeddings of movie overviews. If the optional dependency isn't installed
(it's commented out of requirements.txt by default to keep the base app
lightweight), this transparently falls back to the TF-IDF content model's
similarity so every endpoint still works.
"""
from __future__ import annotations
from typing import List, Tuple, Optional
import numpy as np

try:
    from sentence_transformers import SentenceTransformer
    _HAS_ST = True
except ImportError:
    _HAS_ST = False


class SemanticModel:
    def __init__(self, fallback_content_model=None):
        self.available = _HAS_ST
        self.fallback = fallback_content_model
        self.movie_ids: List[int] = []
        self.embeddings: Optional[np.ndarray] = None
        self._model = None

    def fit(self, movies: list):
        self.movie_ids = [m.id for m in movies]
        if not _HAS_ST or not movies:
            self.embeddings = None
            return
        if self._model is None:
            self._model = SentenceTransformer("all-MiniLM-L6-v2")
        texts = [f"{m.title}. {m.overview or ''} Genres: {m.genres or ''}" for m in movies]
        self.embeddings = self._model.encode(texts, normalize_embeddings=True)

    def similar_to(self, movie_id: int, top_k: int = 12) -> List[Tuple[int, float]]:
        if self.embeddings is None:
            # graceful fallback to content-based similarity
            if self.fallback is not None:
                return self.fallback.similar_to(movie_id, top_k)
            return []
        try:
            idx = self.movie_ids.index(movie_id)
        except ValueError:
            return []
        sims = self.embeddings @ self.embeddings[idx]
        order = np.argsort(sims)[::-1]
        results = []
        for i in order:
            if self.movie_ids[i] == movie_id:
                continue
            results.append((self.movie_ids[i], float(sims[i])))
            if len(results) >= top_k:
                break
        return results
