"""
Hybrid recommendation engine — the core of KMK CineAI.

Combines:
  - Content-based similarity (TF-IDF + cosine)      weight 0.30
  - Semantic similarity (sentence-transformers, or
    TF-IDF fallback when that optional dep is absent) weight 0.25
  - Collaborative filtering (SVD on the rating matrix) weight 0.25
  - User preference match (onboarding genres/langs)   weight 0.10
  - Popularity / recency                              weight 0.10

Weights are configurable via set_weights(). The engine keeps its fitted
models in memory and is refit whenever the underlying data changes
meaningfully (new movie, new rating) via a simple dirty flag so requests
stay fast without needing a background job scheduler for this project size.
"""
from __future__ import annotations
from typing import List, Dict, Optional
from sqlalchemy.orm import Session

from app import models
from app.services.content_model import ContentModel
from app.services.semantic_model import SemanticModel
from app.services.collaborative_model import CollaborativeModel
from app.services.ranking import normalize, DEFAULT_WEIGHTS


class HybridRecommender:
    def __init__(self):
        self.content = ContentModel()
        self.semantic = SemanticModel(fallback_content_model=self.content)
        self.collab = CollaborativeModel()
        self.weights = dict(DEFAULT_WEIGHTS)
        self._dirty = True
        self._movies_cache: Dict[int, models.Movie] = {}

    def set_weights(self, **kwargs):
        for k, v in kwargs.items():
            if k in self.weights:
                self.weights[k] = v

    def mark_dirty(self):
        self._dirty = True

    def refresh(self, db: Session, force: bool = False):
        if not self._dirty and not force:
            return
        movies = db.query(models.Movie).all()
        ratings = db.query(models.Rating).all()
        self._movies_cache = {m.id: m for m in movies}
        self.content.fit(movies)
        self.semantic.fit(movies)
        self.collab.fit(ratings)
        self._dirty = False

    # ---------------- Popularity ----------------

    def popularity_scores(self) -> Dict[int, float]:
        raw = {}
        for mid, m in self._movies_cache.items():
            # blend average rating, vote count and release recency
            recency = max(0, m.release_year - 2000) / 26.0
            raw[mid] = (m.popularity or 0) + (m.rating or 0) * 5 + recency * 3
        return normalize(raw)

    # ---------------- Preference match ----------------

    def preference_scores(self, db: Session, user_id: int) -> Dict[int, float]:
        prefs = db.query(models.UserPreference).filter(models.UserPreference.user_id == user_id).all()
        genre_prefs = {p.value.lower() for p in prefs if p.kind == "genre"}
        lang_prefs = {p.value.lower() for p in prefs if p.kind == "language"}
        actor_prefs = {p.value.lower() for p in prefs if p.kind == "actor"}

        raw = {}
        for mid, m in self._movies_cache.items():
            score = 0.0
            movie_genres = {g.strip().lower() for g in (m.genres or "").split(",") if g.strip()}
            if genre_prefs and movie_genres & genre_prefs:
                score += len(movie_genres & genre_prefs)
            if lang_prefs and (m.language or "").lower() in lang_prefs:
                score += 1
            movie_cast = {c.strip().lower() for c in (m.cast or "").split(",") if c.strip()}
            if actor_prefs and movie_cast & actor_prefs:
                score += 1
            raw[mid] = score
        return normalize(raw) if any(raw.values()) else {k: 0.0 for k in raw}

    # ---------------- Related movies (movie -> movie) ----------------

    def related_to(self, movie_id: int, top_k: int = 12) -> List[Dict]:
        content_sims = dict(self.content.similar_to(movie_id, top_k=40))
        semantic_sims = dict(self.semantic.similar_to(movie_id, top_k=40))
        pop = self.popularity_scores()

        content_n = normalize(content_sims)
        semantic_n = normalize(semantic_sims)

        candidates = set(content_n) | set(semantic_n)
        scored = []
        for mid in candidates:
            score = (
                self.weights["content"] * content_n.get(mid, 0)
                + self.weights["semantic"] * semantic_n.get(mid, 0)
                + self.weights["popularity"] * pop.get(mid, 0)
            )
            scored.append((mid, score))
        scored.sort(key=lambda x: x[1], reverse=True)
        return self._to_scored_payload(scored[:top_k], reason="Similar genre, cast & story")

    # ---------------- Personalized recommendations (user -> movies) ----------------

    def recommend_for_user(self, db: Session, user: Optional[models.User], top_k: int = 20) -> List[Dict]:
        pop = self.popularity_scores()

        if user is None:
            # Guest / cold start: popularity only
            scored = sorted(pop.items(), key=lambda x: x[1], reverse=True)[:top_k]
            return self._to_scored_payload(scored, reason="Trending now")

        rated = db.query(models.Rating).filter(models.Rating.user_id == user.id).all()
        rated_ids = {r.movie_id for r in rated}
        liked_ids = [r.movie_id for r in rated if r.rating >= 3.5]

        if not rated and not liked_ids:
            # True cold start for a brand-new logged-in user: preference-based
            pref = self.preference_scores(db, user.id)
            scored = sorted(
                ((mid, 0.6 * pref.get(mid, 0) + 0.4 * pop.get(mid, 0)) for mid in self._movies_cache),
                key=lambda x: x[1], reverse=True,
            )[:top_k]
            return self._to_scored_payload(scored, reason="Based on your preferences")

        content_scores = normalize(dict(self.content.profile_similarity(liked_ids, top_k=60))) if liked_ids else {}
        semantic_scores = {}
        if liked_ids:
            sem_raw = {}
            for lid in liked_ids:
                for mid, s in self.semantic.similar_to(lid, top_k=30):
                    sem_raw[mid] = max(sem_raw.get(mid, 0), s)
            semantic_scores = normalize(sem_raw)

        collab_raw = dict(self.collab.recommend_for_user(user.id, exclude_movie_ids=rated_ids, top_k=60))
        collab_scores = normalize(collab_raw)

        pref_scores = self.preference_scores(db, user.id)

        candidates = set(content_scores) | set(semantic_scores) | set(collab_scores) | set(self._movies_cache)
        candidates -= rated_ids

        scored = []
        for mid in candidates:
            s = (
                self.weights["content"] * content_scores.get(mid, 0)
                + self.weights["semantic"] * semantic_scores.get(mid, 0)
                + self.weights["collaborative"] * collab_scores.get(mid, 0)
                + self.weights["preference"] * pref_scores.get(mid, 0)
                + self.weights["popularity"] * pop.get(mid, 0)
            )
            scored.append((mid, s))
        scored.sort(key=lambda x: x[1], reverse=True)
        return self._to_scored_payload(scored[:top_k], reason="Recommended for you")

    def because_you_liked(self, db: Session, user: models.User, top_k: int = 10):
        """Returns (anchor_movie, recommendations) for the user's highest-rated movie."""
        top_rating = (
            db.query(models.Rating)
            .filter(models.Rating.user_id == user.id)
            .order_by(models.Rating.rating.desc(), models.Rating.created_at.desc())
            .first()
        )
        if not top_rating:
            return None, []
        anchor = self._movies_cache.get(top_rating.movie_id)
        recs = self.related_to(top_rating.movie_id, top_k=top_k)
        return anchor, recs

    # ---------------- Search (semantic-ish ranking on top of SQL filter) ----------------

    def search_rank(self, query: str, candidate_ids: List[int], top_k: int = 30) -> List[Dict]:
        text_scores = dict(self.content.similar_to_text(query, top_k=200))
        pop = self.popularity_scores()
        scored = []
        for mid in candidate_ids:
            s = 0.7 * text_scores.get(mid, 0) + 0.3 * pop.get(mid, 0)
            scored.append((mid, s))
        scored.sort(key=lambda x: x[1], reverse=True)
        return self._to_scored_payload(scored[:top_k], reason="Best match")

    # ---------------- helpers ----------------

    def _to_scored_payload(self, scored_pairs, reason: str) -> List[Dict]:
        out = []
        for mid, score in scored_pairs:
            m = self._movies_cache.get(mid)
            if not m:
                continue
            out.append({"movie": m, "score": round(float(score), 4), "reason": reason})
        return out


# Module-level singleton used by the routers
engine = HybridRecommender()
