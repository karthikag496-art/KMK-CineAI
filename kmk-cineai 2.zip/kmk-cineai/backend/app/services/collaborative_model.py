"""
Collaborative filtering model.

Builds a user-movie rating matrix and factorizes it with truncated SVD
(scikit-learn) to produce latent-factor predicted ratings for unseen
(user, movie) pairs. Falls back gracefully to an empty predictor when there
isn't enough rating data yet (cold-start), letting the hybrid engine lean on
content/popularity instead.
"""
from __future__ import annotations
from typing import Dict, List, Tuple
import numpy as np
from sklearn.decomposition import TruncatedSVD


class CollaborativeModel:
    def __init__(self, n_components: int = 12):
        self.n_components = n_components
        self.user_ids: List[int] = []
        self.movie_ids: List[int] = []
        self.user_index: Dict[int, int] = {}
        self.movie_index: Dict[int, int] = {}
        self.predicted = None  # dense predicted rating matrix
        self.global_mean = 0.0
        self.fitted = False

    def fit(self, ratings: list):
        """ratings: list of objects with .user_id, .movie_id, .rating"""
        if len(ratings) < 5:
            self.fitted = False
            return

        self.user_ids = sorted({r.user_id for r in ratings})
        self.movie_ids = sorted({r.movie_id for r in ratings})
        self.user_index = {u: i for i, u in enumerate(self.user_ids)}
        self.movie_index = {m: i for i, m in enumerate(self.movie_ids)}

        n_users, n_movies = len(self.user_ids), len(self.movie_ids)
        matrix = np.zeros((n_users, n_movies))
        mask = np.zeros((n_users, n_movies), dtype=bool)

        for r in ratings:
            ui, mi = self.user_index[r.user_id], self.movie_index[r.movie_id]
            matrix[ui, mi] = r.rating
            mask[ui, mi] = True

        self.global_mean = float(matrix[mask].mean()) if mask.any() else 3.0
        filled = np.where(mask, matrix, self.global_mean)

        n_comp = min(self.n_components, max(1, min(n_users, n_movies) - 1))
        if n_comp < 1:
            self.fitted = False
            return

        svd = TruncatedSVD(n_components=n_comp, random_state=42)
        latent_users = svd.fit_transform(filled)
        approx = latent_users @ svd.components_
        self.predicted = np.clip(approx, 0.5, 5.0)
        self.fitted = True

    def predict(self, user_id: int, movie_id: int) -> float:
        if not self.fitted:
            return self.global_mean or 3.0
        ui = self.user_index.get(user_id)
        mi = self.movie_index.get(movie_id)
        if ui is None or mi is None:
            return self.global_mean or 3.0
        return float(self.predicted[ui, mi])

    def recommend_for_user(self, user_id: int, exclude_movie_ids: set, top_k: int = 20) -> List[Tuple[int, float]]:
        if not self.fitted:
            return []
        ui = self.user_index.get(user_id)
        if ui is None:
            return []
        scores = self.predicted[ui]
        order = np.argsort(scores)[::-1]
        results = []
        for mi in order:
            mid = self.movie_ids[mi]
            if mid in exclude_movie_ids:
                continue
            results.append((mid, float(scores[mi])))
            if len(results) >= top_k:
                break
        return results
