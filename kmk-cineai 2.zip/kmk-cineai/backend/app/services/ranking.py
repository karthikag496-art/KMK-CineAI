"""Small numeric helpers used to combine heterogeneous scores into one
comparable [0,1] hybrid score."""
from __future__ import annotations
from typing import Dict


def normalize(values: Dict[int, float]) -> Dict[int, float]:
    if not values:
        return {}
    lo, hi = min(values.values()), max(values.values())
    if hi - lo < 1e-9:
        return {k: 0.5 for k in values}
    return {k: (v - lo) / (hi - lo) for k, v in values.items()}


# Configurable hybrid weights (see services/recommender.py)
DEFAULT_WEIGHTS = {
    "content": 0.30,
    "semantic": 0.25,
    "collaborative": 0.25,
    "preference": 0.10,
    "popularity": 0.10,
}
