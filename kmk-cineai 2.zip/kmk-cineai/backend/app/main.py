import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

from app.database import Base, engine as db_engine
from app.routers import auth, movies, recommendations, ratings, watchlist, users

load_dotenv()

Base.metadata.create_all(bind=db_engine)

app = FastAPI(
    title="KMK CineAI API",
    description="Karthika • Muthumala • Kowsalya — Better Movies. Smarter Recommendations.",
    version="1.0.0",
)

origins = os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(movies.router)
app.include_router(recommendations.router)
app.include_router(ratings.router)
app.include_router(watchlist.router)
app.include_router(users.router)


@app.get("/health")
def health():
    return {"status": "ok", "app": "KMK CineAI"}


@app.get("/")
def root():
    return {"message": "KMK CineAI API — see /docs for interactive API documentation."}
