"""
CSV import/export utility so larger datasets (e.g. a trimmed MovieLens/TMDB
export) can be loaded later without touching the application code.

Usage:
    python data_loader.py export        # writes data/movies.csv from movie_data.py
    python data_loader.py import <path> # loads a CSV into the database
"""
import sys
import pandas as pd
from app.database import SessionLocal, Base, engine
from app import models
from movie_data import MOVIES

CSV_COLUMNS = [
    "title", "overview", "genres", "cast", "actresses", "director", "music_director",
    "writer", "producer", "language", "release_year", "release_date", "duration",
    "poster_url", "backdrop_url", "rating", "vote_count", "popularity",
]


def export_csv(path: str = "data/movies.csv"):
    df = pd.DataFrame(MOVIES)[CSV_COLUMNS]
    df.to_csv(path, index=False)
    print(f"Exported {len(df)} movies to {path}")


def import_csv(path: str):
    Base.metadata.create_all(bind=engine)
    df = pd.read_csv(path)
    db = SessionLocal()
    created = 0
    try:
        for _, row in df.iterrows():
            exists = db.query(models.Movie).filter(models.Movie.title == row["title"]).first()
            if exists:
                continue
            movie = models.Movie(**{col: row.get(col, "") for col in CSV_COLUMNS if col in row})
            db.add(movie)
            created += 1
        db.commit()
    finally:
        db.close()
    print(f"Imported {created} new movies from {path}")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    if sys.argv[1] == "export":
        export_csv(sys.argv[2] if len(sys.argv) > 2 else "data/movies.csv")
    elif sys.argv[1] == "import":
        if len(sys.argv) < 3:
            print("Usage: python data_loader.py import <path>")
            sys.exit(1)
        import_csv(sys.argv[2])
    else:
        print(__doc__)
