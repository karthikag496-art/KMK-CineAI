import axios from "axios";

const API_BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:8000";

const api = axios.create({
  baseURL: API_BASE_URL,
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem("kmk_token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      localStorage.removeItem("kmk_token");
      localStorage.removeItem("kmk_user");
    }
    return Promise.reject(err);
  }
);

// ---------- Auth ----------
export const registerUser = (data) => api.post("/auth/register", data);
export const loginUser = (data) => api.post("/auth/login", data);
export const getMe = () => api.get("/auth/me");

// ---------- Movies ----------
export const listMovies = (params) => api.get("/movies/", { params });
export const getMovie = (id) => api.get(`/movies/${id}`);
export const searchMovies = (q) => api.get("/movies/search", { params: { q } });
export const getRelatedMovies = (id, limit = 12) => api.get(`/movies/${id}/related`, { params: { limit } });
export const getGenres = () => api.get("/genres");

export const getActor = (name) => api.get(`/actors/${encodeURIComponent(name)}`);
export const getActress = (name) => api.get(`/actresses/${encodeURIComponent(name)}`);
export const getDirector = (name) => api.get(`/directors/${encodeURIComponent(name)}`);
export const getMusicDirector = (name) => api.get(`/music-directors/${encodeURIComponent(name)}`);

// ---------- Recommendations ----------
export const getRecommendations = (limit = 20) => api.get("/recommendations/", { params: { limit } });
export const getBecauseYouLiked = () => api.get("/recommendations/because-you-liked");
export const submitOnboarding = (data) => api.post("/recommendations/onboarding", data);

// ---------- Ratings ----------
export const rateMovie = (movieId, rating) => api.post(`/movies/${movieId}/rating`, { rating });
export const deleteRating = (movieId) => api.delete(`/movies/${movieId}/rating`);
export const getMyRatings = () => api.get("/users/me/ratings");

// ---------- Watchlist ----------
export const addToWatchlist = (movieId) => api.post(`/watchlist/${movieId}`);
export const removeFromWatchlist = (movieId) => api.delete(`/watchlist/${movieId}`);
export const getWatchlist = () => api.get("/watchlist");

export default api;
