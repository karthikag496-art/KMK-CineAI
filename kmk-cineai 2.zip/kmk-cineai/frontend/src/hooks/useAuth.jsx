import { createContext, useContext, useEffect, useState, useCallback } from "react";
import { loginUser, registerUser, getMe } from "../services/api";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const stored = localStorage.getItem("kmk_user");
    return stored ? JSON.parse(stored) : null;
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem("kmk_token");
    if (!token) {
      setLoading(false);
      return;
    }
    getMe()
      .then((res) => {
        setUser(res.data);
        localStorage.setItem("kmk_user", JSON.stringify(res.data));
      })
      .catch(() => {
        localStorage.removeItem("kmk_token");
        localStorage.removeItem("kmk_user");
        setUser(null);
      })
      .finally(() => setLoading(false));
  }, []);

  const login = useCallback(async (email, password) => {
    const res = await loginUser({ email, password });
    localStorage.setItem("kmk_token", res.data.access_token);
    localStorage.setItem("kmk_user", JSON.stringify(res.data.user));
    setUser(res.data.user);
    return res.data.user;
  }, []);

  const register = useCallback(async (username, email, password) => {
    const res = await registerUser({ username, email, password });
    localStorage.setItem("kmk_token", res.data.access_token);
    localStorage.setItem("kmk_user", JSON.stringify(res.data.user));
    setUser(res.data.user);
    return res.data.user;
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem("kmk_token");
    localStorage.removeItem("kmk_user");
    setUser(null);
  }, []);

  const isGuest = !user;

  return (
    <AuthContext.Provider value={{ user, setUser, login, register, logout, isGuest, loading }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
