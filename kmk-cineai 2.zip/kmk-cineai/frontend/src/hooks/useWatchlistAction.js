import { useState, useCallback, useEffect } from "react";
import { useAuth } from "./useAuth";
import { getWatchlist, addToWatchlist, removeFromWatchlist } from "../services/api";

export function useWatchlistAction() {
  const { isGuest } = useAuth();
  const [watchlistIds, setWatchlistIds] = useState(new Set());
  const [guestModalOpen, setGuestModalOpen] = useState(false);

  const refresh = useCallback(() => {
    if (isGuest) return;
    getWatchlist().then((res) => setWatchlistIds(new Set(res.data.map((w) => w.movie_id)))).catch(() => {});
  }, [isGuest]);

  useEffect(() => { refresh(); }, [refresh]);

  const toggleWatchlist = useCallback(async (movie) => {
    if (isGuest) {
      setGuestModalOpen(true);
      return;
    }
    if (watchlistIds.has(movie.id)) {
      await removeFromWatchlist(movie.id);
      setWatchlistIds((prev) => {
        const next = new Set(prev);
        next.delete(movie.id);
        return next;
      });
    } else {
      await addToWatchlist(movie.id);
      setWatchlistIds((prev) => new Set(prev).add(movie.id));
    }
  }, [isGuest, watchlistIds]);

  return { watchlistIds, toggleWatchlist, guestModalOpen, setGuestModalOpen, refreshWatchlist: refresh };
}
