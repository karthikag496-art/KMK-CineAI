import { Routes, Route, Navigate, useLocation } from "react-router-dom";
import Layout from "./components/Layout";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Onboarding from "./pages/Onboarding";
import Home from "./pages/Home";
import Discover from "./pages/Discover";
import Recommendations from "./pages/Recommendations";
import MovieDetails from "./pages/MovieDetails";
import Search from "./pages/Search";
import Watchlist from "./pages/Watchlist";
import Ratings from "./pages/Ratings";
import GenrePage from "./pages/GenrePage";
import PersonPage from "./pages/PersonPage";
import Profile from "./pages/Profile";
import { useAuth } from "./hooks/useAuth";
import { LoadingSpinner } from "./components/Feedback";

function RequireAuth({ children }) {
  const { isGuest, loading } = useAuth();
  const location = useLocation();
  if (loading) return <LoadingSpinner />;
  if (isGuest) return <Navigate to="/login" state={{ from: location.pathname }} replace />;
  return children;
}

function Shell({ children }) {
  return <Layout>{children}</Layout>;
}

export default function App() {
  const { loading } = useAuth();
  if (loading) return <LoadingSpinner label="Loading KMK CineAI..." />;

  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route
        path="/onboarding"
        element={
          <RequireAuth>
            <Onboarding />
          </RequireAuth>
        }
      />

      <Route path="/" element={<Shell><Home /></Shell>} />
      <Route path="/discover" element={<Shell><Discover /></Shell>} />
      <Route path="/recommendations" element={<Shell><Recommendations /></Shell>} />
      <Route path="/movie/:id" element={<Shell><MovieDetails /></Shell>} />
      <Route path="/search" element={<Shell><Search /></Shell>} />
      <Route path="/genres/:genre" element={<Shell><GenrePage /></Shell>} />
      <Route path="/actor/:name" element={<Shell><PersonPage kind="actor" /></Shell>} />
      <Route path="/actress/:name" element={<Shell><PersonPage kind="actress" /></Shell>} />
      <Route path="/director/:name" element={<Shell><PersonPage kind="director" /></Shell>} />
      <Route path="/music-director/:name" element={<Shell><PersonPage kind="music-director" /></Shell>} />

      <Route
        path="/watchlist"
        element={
          <RequireAuth>
            <Shell><Watchlist /></Shell>
          </RequireAuth>
        }
      />
      <Route
        path="/ratings"
        element={
          <RequireAuth>
            <Shell><Ratings /></Shell>
          </RequireAuth>
        }
      />
      <Route
        path="/profile"
        element={
          <RequireAuth>
            <Shell><Profile /></Shell>
          </RequireAuth>
        }
      />

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
