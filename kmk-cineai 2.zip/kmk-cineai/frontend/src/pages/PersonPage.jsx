import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import MovieRow from "../components/MovieRow";
import { LoadingSpinner, EmptyState } from "../components/Feedback";
import { useWatchlistAction } from "../hooks/useWatchlistAction";
import { getActor, getActress, getDirector, getMusicDirector } from "../services/api";

const FETCHERS = {
  actor: getActor,
  actress: getActress,
  director: getDirector,
  "music-director": getMusicDirector,
};

const LABELS = {
  actor: "Actor",
  actress: "Actress",
  director: "Director",
  "music-director": "Music Director",
};

export default function PersonPage({ kind }) {
  const { name } = useParams();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const { watchlistIds, toggleWatchlist } = useWatchlistAction();

  useEffect(() => {
    setLoading(true);
    setNotFound(false);
    FETCHERS[kind](name)
      .then((res) => setData(res.data))
      .catch(() => setNotFound(true))
      .finally(() => setLoading(false));
  }, [kind, name]);

  if (loading) return <LoadingSpinner />;
  if (notFound || !data) return <EmptyState title="Not found." subtitle="We couldn't find this person." />;

  return (
    <div>
      <div className="panel" style={{ marginBottom: 12, display: "flex", alignItems: "center", gap: 18 }}>
        <div className="profile-avatar" style={{ width: 64, height: 64, fontSize: 24 }}>
          {data.name[0]}
        </div>
        <div>
          <div className="text-dim" style={{ fontSize: 12, textTransform: "uppercase", letterSpacing: "0.05em" }}>{LABELS[kind]}</div>
          <h2>{data.name}</h2>
        </div>
      </div>

      <MovieRow title="Movies" movies={data.movies} onAddToWatchlist={toggleWatchlist} watchlistIds={watchlistIds} />
      {data.popular && <MovieRow title="Popular Movies" movies={data.popular} onAddToWatchlist={toggleWatchlist} watchlistIds={watchlistIds} />}
      {data.highest_rated && <MovieRow title="Highest Rated Movies" movies={data.highest_rated} onAddToWatchlist={toggleWatchlist} watchlistIds={watchlistIds} />}
    </div>
  );
}
