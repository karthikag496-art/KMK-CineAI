import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { EmptyState, LoadingSpinner } from "../components/Feedback";
import { TrashIcon, StarIcon } from "../components/Icons";
import { getWatchlist, removeFromWatchlist } from "../services/api";

export default function Watchlist() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    getWatchlist().then((res) => setItems(res.data)).finally(() => setLoading(false));
  }, []);

  async function handleRemove(movieId) {
    setItems((prev) => prev.filter((i) => i.movie_id !== movieId));
    try {
      await removeFromWatchlist(movieId);
    } catch {
      // no-op — a refresh will resync on next visit
    }
  }

  if (loading) return <LoadingSpinner />;

  return (
    <div>
      <div className="section-head"><h2>My Watchlist</h2></div>
      {items.length === 0 ? (
        <EmptyState title="Your watchlist is waiting for its first movie." subtitle="Browse movies and tap the + button to add them here." />
      ) : (
        <div className="movie-grid">
          {items.map((item) => (
            <div key={item.id} className="movie-card">
              <div className="poster-wrap" onClick={() => navigate(`/movie/${item.movie.id}`)}>
                <img src={item.movie.poster_url} alt={item.movie.title} />
                <div className="rating-badge"><StarIcon width={11} height={11} fill="currentColor" /> {item.movie.rating.toFixed(1)}</div>
              </div>
              <div className="meta">
                <h4>{item.movie.title}</h4>
                <div className="sub">{item.movie.genres?.split(",")[0]} • {item.movie.release_year}</div>
                <button className="btn btn-ghost btn-sm w-full" style={{ marginTop: 8 }} onClick={() => handleRemove(item.movie_id)}>
                  <TrashIcon width={13} height={13} /> Remove
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
