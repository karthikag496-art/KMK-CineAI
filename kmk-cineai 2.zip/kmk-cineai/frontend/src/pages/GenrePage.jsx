import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import MovieCard from "../components/MovieCard";
import GuestModal from "../components/GuestModal";
import { LoadingSpinner, EmptyState } from "../components/Feedback";
import { GENRE_EMOJI } from "../components/Icons";
import { useWatchlistAction } from "../hooks/useWatchlistAction";
import { listMovies } from "../services/api";

export default function GenrePage() {
  const { genre } = useParams();
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(true);
  const { watchlistIds, toggleWatchlist, guestModalOpen, setGuestModalOpen } = useWatchlistAction();

  useEffect(() => {
    setLoading(true);
    listMovies({ genre, sort: "popularity", limit: 60 }).then((res) => setMovies(res.data)).finally(() => setLoading(false));
  }, [genre]);

  return (
    <div>
      <div className="section-head">
        <h2>{GENRE_EMOJI[genre] || "🎬"} {genre} Movies</h2>
      </div>
      {loading ? (
        <LoadingSpinner />
      ) : movies.length === 0 ? (
        <EmptyState title="No movies found." subtitle={`No movies in the ${genre} genre yet.`} />
      ) : (
        <div className="movie-grid">
          {movies.map((m) => (
            <MovieCard key={m.id} movie={m} onAddToWatchlist={toggleWatchlist} isInWatchlist={watchlistIds.has(m.id)} />
          ))}
        </div>
      )}
      <GuestModal open={guestModalOpen} onClose={() => setGuestModalOpen(false)} />
    </div>
  );
}
