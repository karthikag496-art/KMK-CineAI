import { useNavigate } from "react-router-dom";
import { useAuth } from "../hooks/useAuth";

export default function Profile() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  if (!user) return null;

  return (
    <div style={{ maxWidth: 480, margin: "0 auto" }}>
      <div className="panel" style={{ textAlign: "center" }}>
        <div className="profile-avatar" style={{ width: 72, height: 72, fontSize: 28, margin: "0 auto 16px" }}>
          {user.username[0].toUpperCase()}
        </div>
        <h2>{user.username}</h2>
        <p className="text-dim" style={{ marginBottom: 24 }}>{user.email}</p>

        <div className="flex-col gap-12">
          <button className="btn btn-secondary btn-block" onClick={() => navigate("/watchlist")}>My Watchlist</button>
          <button className="btn btn-secondary btn-block" onClick={() => navigate("/ratings")}>My Ratings</button>
          <button className="btn btn-outline btn-block" onClick={() => navigate("/onboarding")}>Update Genre Preferences</button>
          <button className="btn btn-ghost btn-block" onClick={() => { logout(); navigate("/"); }}>Logout</button>
        </div>
      </div>
    </div>
  );
}
