import { useEffect, useState } from "react";
import MovieCard from "../components/MovieCard";
import { FilterPanel, RightPanel } from "../components/FilterPanel";
import GuestModal from "../components/GuestModal";
import { LoadingSpinner, EmptyState } from "../components/Feedback";
import { useWatchlistAction } from "../hooks/useWatchlistAction";
import { listMovies, getGenres } from "../services/api";

export default function Discover() {
  const [movies, setMovies] = useState([]);
  const [genres, setGenres] = useState([]);
  const [filters, setFilters] = useState({ sort: "trending", genre: null, language: null });
  const [loading, setLoading] = useState(true);
  const { watchlistIds, toggleWatchlist, guestModalOpen, setGuestModalOpen } = useWatchlistAction();

  useEffect(() => {
    getGenres().then((res) => setGenres(res.data));
  }, []);

  useEffect(() => {
    setLoading(true);
    listMovies({ sort: filters.sort, genre: filters.genre, language: filters.language, limit: 60 })
      .then((res) => setMovies(res.data))
      .finally(() => setLoading(false));
  }, [filters]);

  return (
    <div>
      <div className="section-head">
        <h2>Discover Movies</h2>
      </div>
      <div className="page-with-panel">
        <div>
          {loading ? (
            <LoadingSpinner />
          ) : movies.length === 0 ? (
            <EmptyState title="No movies found." subtitle="Try a different genre, language, or sort order." />
          ) : (
            <div className="movie-grid">
              {movies.map((m) => (
                <MovieCard key={m.id} movie={m} onAddToWatchlist={toggleWatchlist} isInWatchlist={watchlistIds.has(m.id)} />
              ))}
            </div>
          )}
        </div>
        <RightPanel genres={genres}>
          <FilterPanel filters={filters} setFilters={setFilters} genres={genres} />
        </RightPanel>
      </div>
      <GuestModal open={guestModalOpen} onClose={() => setGuestModalOpen(false)} />
    </div>
  );
}
