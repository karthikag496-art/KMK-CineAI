import { useEffect, useState } from "react";
import MovieCard from "../components/MovieCard";
import GuestModal from "../components/GuestModal";
import { LoadingSpinner, EmptyState } from "../components/Feedback";
import { useAuth } from "../hooks/useAuth";
import { useWatchlistAction } from "../hooks/useWatchlistAction";
import { getRecommendations } from "../services/api";
import { useNavigate } from "react-router-dom";

export default function Recommendations() {
  const { isGuest } = useAuth();
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(true);
  const { watchlistIds, toggleWatchlist, guestModalOpen, setGuestModalOpen } = useWatchlistAction();
  const navigate = useNavigate();

  useEffect(() => {
    getRecommendations(40).then((res) => setMovies(res.data)).finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <div className="section-head">
        <h2>{isGuest ? "Trending & Popular" : "Recommended For You"}</h2>
      </div>

      {isGuest && (
        <div className="panel" style={{ marginBottom: 24 }}>
          <p className="text-dim" style={{ marginBottom: 12 }}>
            You're browsing as a guest, so these are trending and popular picks. Create an account for
            recommendations built from your ratings and taste.
          </p>
          <button className="btn btn-primary btn-sm" onClick={() => navigate("/register")}>Login to Get Personalized Recommendations</button>
        </div>
      )}

      {loading ? (
        <LoadingSpinner label="Running the recommendation engine..." />
      ) : movies.length === 0 ? (
        <EmptyState title="No recommendations yet." subtitle="Rate a few movies and check back." />
      ) : (
        <div className="movie-grid">
          {movies.map((m) => (
            <MovieCard key={m.id} movie={m} onAddToWatchlist={toggleWatchlist} isInWatchlist={watchlistIds.has(m.id)} />
          ))}
        </div>
      )}
      <GuestModal open={guestModalOpen} onClose={() => setGuestModalOpen(false)} />
    </div>
  );
}
