import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import MovieCard from "../components/MovieCard";
import GuestModal from "../components/GuestModal";
import { LoadingSpinner, EmptyState } from "../components/Feedback";
import { useWatchlistAction } from "../hooks/useWatchlistAction";
import { searchMovies, listMovies } from "../services/api";

export default function Search() {
  const [params] = useSearchParams();
  const q = params.get("q") || "";
  const [results, setResults] = useState([]);
  const [popular, setPopular] = useState([]);
  const [loading, setLoading] = useState(true);
  const { watchlistIds, toggleWatchlist, guestModalOpen, setGuestModalOpen } = useWatchlistAction();

  useEffect(() => {
    if (!q) return;
    setLoading(true);
    Promise.all([searchMovies(q), listMovies({ sort: "popularity", limit: 8 })])
      .then(([resultsRes, popularRes]) => {
        setResults(resultsRes.data);
        setPopular(popularRes.data);
      })
      .finally(() => setLoading(false));
  }, [q]);

  if (!q) return <EmptyState title="Search for something." subtitle="Try a movie title, actor, director, or genre." />;
  if (loading) return <LoadingSpinner label={`Searching for "${q}"...`} />;

  return (
    <div>
      <div className="section-head"><h2>Search Results for "{q}"</h2></div>

      {results.length === 0 ? (
        <EmptyState title="No movies found." subtitle="Try searching for another movie, actor, or genre." />
      ) : (
        <div className="movie-grid" style={{ marginBottom: 12 }}>
          {results.map((m) => (
            <MovieCard key={m.id} movie={m} onAddToWatchlist={toggleWatchlist} isInWatchlist={watchlistIds.has(m.id)} />
          ))}
        </div>
      )}

      {popular.length > 0 && (
        <div className="section">
          <div className="section-head"><h2>Popular Movies</h2></div>
          <div className="movie-row">
            {popular.map((m) => (
              <MovieCard key={m.id} movie={m} onAddToWatchlist={toggleWatchlist} isInWatchlist={watchlistIds.has(m.id)} />
            ))}
          </div>
        </div>
      )}
      <GuestModal open={guestModalOpen} onClose={() => setGuestModalOpen(false)} />
    </div>
  );
}
