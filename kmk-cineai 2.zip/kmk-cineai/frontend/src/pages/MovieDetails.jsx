import { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import MovieRow from "../components/MovieRow";
import RatingStars from "../components/RatingStars";
import GuestModal from "../components/GuestModal";
import { LoadingSpinner, ErrorMessage } from "../components/Feedback";
import { StarIcon, PlayIcon, PlusIcon, CheckIcon } from "../components/Icons";
import { useAuth } from "../hooks/useAuth";
import { useWatchlistAction } from "../hooks/useWatchlistAction";
import { getMovie, getRelatedMovies, rateMovie, getMyRatings } from "../services/api";

function splitList(str) {
  return (str || "").split(",").map((s) => s.trim()).filter(Boolean);
}

export default function MovieDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { isGuest } = useAuth();
  const { watchlistIds, toggleWatchlist, guestModalOpen, setGuestModalOpen } = useWatchlistAction();

  const [movie, setMovie] = useState(null);
  const [related, setRelated] = useState([]);
  const [myRating, setMyRating] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [rateMsg, setRateMsg] = useState("");

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError("");
    Promise.all([
      getMovie(id),
      getRelatedMovies(id, 12),
      isGuest ? Promise.resolve(null) : getMyRatings().catch(() => null),
    ])
      .then(([movieRes, relatedRes, ratingsRes]) => {
        if (cancelled) return;
        setMovie(movieRes.data);
        setRelated(relatedRes.data);
        if (ratingsRes) {
          const existing = ratingsRes.data.find((r) => r.movie_id === Number(id));
          setMyRating(existing ? existing.rating : 0);
        } else {
          setMyRating(0);
        }
      })
      .catch(() => !cancelled && setError("Movie not found."))
      .finally(() => !cancelled && setLoading(false));
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, isGuest]);

  async function handleRate(n) {
    if (isGuest) {
      setGuestModalOpen(true);
      return;
    }
    setMyRating(n);
    try {
      const res = await rateMovie(id, n);
      setMovie((m) => ({ ...m, rating: res.data.movie.rating, vote_count: res.data.movie.vote_count }));
      setRateMsg("Rating saved!");
      setTimeout(() => setRateMsg(""), 2000);
    } catch {
      setRateMsg("Couldn't save your rating.");
    }
  }

  function handleWatchlist() {
    if (isGuest) {
      setGuestModalOpen(true);
      return;
    }
    toggleWatchlist(movie);
  }

  if (loading) return <LoadingSpinner label="Loading movie details..." />;
  if (error || !movie) return <ErrorMessage message={error || "Movie not found."} />;

  const cast = splitList(movie.cast);
  const actresses = splitList(movie.actresses);
  const genres = splitList(movie.genres);
  const inWatchlist = watchlistIds.has(movie.id);

  return (
    <div>
      <div className="details-hero">
        <div className="hero-bg" style={{ position: "absolute", inset: 0, backgroundImage: `url(${movie.backdrop_url})`, backgroundSize: "cover", backgroundPosition: "center" }} />
        <div className="hero-scrim" />
        <div className="hero-content">
          <h1 className="hero-title">{movie.title}</h1>
          <div className="hero-meta">
            <span className="rating-pill"><StarIcon width={13} height={13} fill="currentColor" /> {movie.rating.toFixed(1)}/5</span>
            <span>{movie.vote_count} ratings</span>
            <span>{movie.release_year}</span>
            <span>{movie.duration} min</span>
            <span>{movie.language}</span>
          </div>
          <div className="hero-genres">
            {genres.map((g) => <Link key={g} to={`/genres/${encodeURIComponent(g)}`} className="chip outline">{g}</Link>)}
          </div>
          <p className="hero-desc">{movie.overview}</p>
          <div className="hero-actions">
            <button className="btn btn-primary"><PlayIcon width={15} height={15} /> Watch Trailer</button>
            <button className="btn btn-ghost" onClick={handleWatchlist}>
              {inWatchlist ? <CheckIcon width={15} height={15} /> : <PlusIcon width={15} height={15} />}
              {inWatchlist ? "In Watchlist" : "Add to Watchlist"}
            </button>
          </div>
        </div>
      </div>

      <div className="details-body">
        <div>
          <div className="panel">
            <h3 style={{ marginBottom: 6 }}>Overview</h3>
            <p className="text-dim" style={{ lineHeight: 1.6, fontSize: 14.5 }}>{movie.overview}</p>

            <div className="info-grid">
              <div className="info-item">
                <div className="label">Director</div>
                <div className="value"><Link to={`/director/${encodeURIComponent(movie.director)}`}>{movie.director}</Link></div>
              </div>
              {movie.writer && (
                <div className="info-item"><div className="label">Writer</div><div className="value">{movie.writer}</div></div>
              )}
              {movie.producer && (
                <div className="info-item"><div className="label">Producer</div><div className="value">{movie.producer}</div></div>
              )}
              {movie.music_director && (
                <div className="info-item">
                  <div className="label">Music Director</div>
                  <div className="value"><Link to={`/music-director/${encodeURIComponent(movie.music_director)}`}>{movie.music_director}</Link></div>
                </div>
              )}
              <div className="info-item"><div className="label">Release Date</div><div className="value">{movie.release_date || movie.release_year}</div></div>
              <div className="info-item"><div className="label">Popularity</div><div className="value">{Math.round(movie.popularity)}</div></div>
            </div>

            {cast.length > 0 && (
              <>
                <h4 style={{ marginTop: 22, marginBottom: 8, fontSize: 14 }}>Cast</h4>
                <div className="person-chip-row">
                  {cast.map((c) => (
                    <Link key={c} to={`/actor/${encodeURIComponent(c)}`} className="person-chip">{c}</Link>
                  ))}
                </div>
              </>
            )}
            {actresses.length > 0 && (
              <>
                <h4 style={{ marginTop: 18, marginBottom: 8, fontSize: 14 }}>Actresses</h4>
                <div className="person-chip-row">
                  {actresses.map((a) => (
                    <Link key={a} to={`/actress/${encodeURIComponent(a)}`} className="person-chip">{a}</Link>
                  ))}
                </div>
              </>
            )}
          </div>
        </div>

        <div className="panel rate-box">
          <h4>Rate This Movie</h4>
          <RatingStars value={myRating} onRate={handleRate} size={28} />
          {rateMsg && <p className="text-dim" style={{ fontSize: 12.5 }}>{rateMsg}</p>}
          {isGuest && <p className="text-dim" style={{ fontSize: 12.5, textAlign: "center" }}>Login to rate movies.</p>}
        </div>
      </div>

      <MovieRow title="AI Recommended Movies" movies={related} onAddToWatchlist={toggleWatchlist} watchlistIds={watchlistIds} />
      <MovieRow title="Related Movies" movies={[...related].reverse()} onAddToWatchlist={toggleWatchlist} watchlistIds={watchlistIds} />

      <GuestModal open={guestModalOpen} onClose={() => setGuestModalOpen(false)} />
    </div>
  );
}
