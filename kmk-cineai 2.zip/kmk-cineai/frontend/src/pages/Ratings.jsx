import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { EmptyState, LoadingSpinner } from "../components/Feedback";
import RatingStars from "../components/RatingStars";
import { getMyRatings, rateMovie, deleteRating } from "../services/api";

export default function Ratings() {
  const [ratings, setRatings] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    getMyRatings().then((res) => setRatings(res.data)).finally(() => setLoading(false));
  }, []);

  async function handleChange(movieId, value) {
    setRatings((prev) => prev.map((r) => (r.movie_id === movieId ? { ...r, rating: value } : r)));
    await rateMovie(movieId, value);
  }

  async function handleRemove(movieId) {
    setRatings((prev) => prev.filter((r) => r.movie_id !== movieId));
    await deleteRating(movieId);
  }

  if (loading) return <LoadingSpinner />;

  return (
    <div>
      <div className="section-head"><h2>My Ratings</h2></div>
      {ratings.length === 0 ? (
        <EmptyState title="You haven't rated any movies yet." subtitle="Rate movies from their details page — it powers your personalized recommendations." />
      ) : (
        <div className="flex-col gap-12">
          {ratings.map((r) => (
            <div key={r.id} className="panel flex items-center gap-12" style={{ justifyContent: "space-between" }}>
              <div className="flex items-center gap-12" style={{ cursor: "pointer", flex: 1 }} onClick={() => navigate(`/movie/${r.movie.id}`)}>
                <img src={r.movie.poster_url} alt={r.movie.title} style={{ width: 50, height: 72, objectFit: "cover", borderRadius: 8 }} />
                <div>
                  <div style={{ fontWeight: 700, fontSize: 15 }}>{r.movie.title}</div>
                  <div className="text-dim" style={{ fontSize: 12.5 }}>{r.movie.genres?.split(",")[0]} • {r.movie.release_year}</div>
                </div>
              </div>
              <RatingStars value={r.rating} onRate={(v) => handleChange(r.movie_id, v)} size={18} />
              <button className="btn btn-ghost btn-sm" onClick={() => handleRemove(r.movie_id)}>Remove</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
