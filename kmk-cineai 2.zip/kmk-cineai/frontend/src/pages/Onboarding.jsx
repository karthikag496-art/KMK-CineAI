import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { getGenres, submitOnboarding } from "../services/api";
import GenreGrid from "../components/GenreGrid";
import { useAuth } from "../hooks/useAuth";

const LANGUAGES = ["Tamil", "English", "Hindi", "Telugu", "Korean", "Japanese", "Chinese"];

export default function Onboarding() {
  const [genres, setGenres] = useState([]);
  const [selectedGenres, setSelectedGenres] = useState([]);
  const [selectedLangs, setSelectedLangs] = useState([]);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { setUser, user } = useAuth();

  useEffect(() => {
    getGenres().then((res) => setGenres(res.data));
  }, []);

  function toggleGenre(g) {
    setSelectedGenres((cur) => (cur.includes(g) ? cur.filter((x) => x !== g) : [...cur, g]));
  }
  function toggleLang(l) {
    setSelectedLangs((cur) => (cur.includes(l) ? cur.filter((x) => x !== l) : [...cur, l]));
  }

  async function finish() {
    setLoading(true);
    try {
      await submitOnboarding({ genres: selectedGenres, languages: selectedLangs, actors: [] });
      setUser({ ...user, onboarded: 1 });
      navigate("/");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="onboarding-shell fade-in">
      <h1 style={{ fontSize: 28, marginBottom: 8 }}>Tell us what you love watching.</h1>
      <p className="text-dim">Select a few genres to help us build your first recommendations.</p>

      <GenreGrid genres={genres} selected={selectedGenres} onToggle={toggleGenre} />

      <h3 style={{ marginBottom: 14 }}>Favorite Languages (optional)</h3>
      <div className="filter-chips" style={{ justifyContent: "center", marginBottom: 36 }}>
        {LANGUAGES.map((l) => (
          <button key={l} className={`chip ${selectedLangs.includes(l) ? "active" : "outline"}`} onClick={() => toggleLang(l)}>
            {l}
          </button>
        ))}
      </div>

      <button className="btn btn-primary" onClick={finish} disabled={loading || selectedGenres.length === 0}>
        {loading ? "Building your picks..." : "Create My Recommendations"}
      </button>
      <div style={{ marginTop: 14 }}>
        <button className="btn btn-ghost btn-sm" onClick={() => navigate("/")}>Skip for now</button>
      </div>
    </div>
  );
}
