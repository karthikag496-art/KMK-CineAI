import { useState, useEffect } from "react";
import { useNavigate, Link, useLocation } from "react-router-dom";
import { useAuth } from "../hooks/useAuth";
import { listMovies } from "../services/api";
import { StarIcon } from "../components/Icons";
import { ErrorMessage } from "../components/Feedback";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [heroMovie, setHeroMovie] = useState(null);
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    listMovies({ sort: "trending", limit: 1 }).then((res) => setHeroMovie(res.data[0])).catch(() => {});
  }, []);

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await login(email, password);
      navigate(location.state?.from || "/");
    } catch (err) {
      setError(err.response?.data?.detail || "Incorrect email or password.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="auth-shell">
      <div className="auth-visual">
        {heroMovie && <div className="bg" style={{ backgroundImage: `url(${heroMovie.backdrop_url})` }} />}
        <div className="scrim" />
        {heroMovie && (
          <div className="auth-visual-content">
            <span className="hero-tag">NOW STREAMING</span>
            <h1 className="hero-title">{heroMovie.title}</h1>
            <div className="hero-meta">
              <span className="rating-pill"><StarIcon width={13} height={13} fill="currentColor" /> {heroMovie.rating.toFixed(1)}/5</span>
              <span>{heroMovie.release_year}</span>
              <span>{heroMovie.language}</span>
            </div>
            <div className="hero-genres">
              {heroMovie.genres.split(",").slice(0, 3).map((g) => <span key={g} className="chip outline">{g}</span>)}
            </div>
            <p className="hero-desc">{heroMovie.overview}</p>
            <div className="hero-credits">
              <div><span className="label">Director</span>{heroMovie.director}</div>
              <div><span className="label">Actor</span>{heroMovie.cast?.split(",")[0]}</div>
              {heroMovie.actresses && <div><span className="label">Actress</span>{heroMovie.actresses.split(",")[0]}</div>}
              {heroMovie.music_director && <div><span className="label">Music Director</span>{heroMovie.music_director}</div>}
            </div>
          </div>
        )}
      </div>

      <div className="auth-panel">
        <div className="auth-card fade-in">
          <div className="brand">
            <div className="logo-mark">K</div>
            <div className="brand-text">
              <strong>KMK CineAI</strong>
              <span>Better Movies. Smarter Recommendations.</span>
            </div>
          </div>
          <h1>Welcome Back!</h1>
          <p className="lead">Sign in to continue your movie journey.</p>

          <ErrorMessage message={error} />

          <form onSubmit={handleSubmit}>
            <div className="field">
              <label>Email Address</label>
              <input className="input" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
            </div>
            <div className="field">
              <label>Password</label>
              <input className="input" type="password" required value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" />
            </div>
            <button className="btn btn-primary btn-block" type="submit" disabled={loading}>
              {loading ? "Signing in..." : "Login"}
            </button>
          </form>

          <div style={{ textAlign: "center", marginTop: 14 }}>
            <Link to="#" className="text-dim" style={{ fontSize: 13 }}>Forgot Password?</Link>
          </div>

          <div className="auth-divider">OR</div>

          <button className="btn btn-ghost btn-block" onClick={() => navigate("/")}>Continue as Guest</button>

          <div className="auth-footer">
            Don't have an account? <Link to="/register">Create Account</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
