import { useEffect, useState } from "react";
import HeroCarousel from "../components/HeroCarousel";
import MovieRow from "../components/MovieRow";
import GenreGrid from "../components/GenreGrid";
import { RightPanel } from "../components/FilterPanel";
import GuestModal from "../components/GuestModal";
import { LoadingSpinner, ErrorMessage } from "../components/Feedback";
import { useAuth } from "../hooks/useAuth";
import { useWatchlistAction } from "../hooks/useWatchlistAction";
import { listMovies, getRecommendations, getGenres, getBecauseYouLiked } from "../services/api";

export default function Home() {
  const { isGuest } = useAuth();
  const { watchlistIds, toggleWatchlist, guestModalOpen, setGuestModalOpen } = useWatchlistAction();

  const [trending, setTrending] = useState([]);
  const [recommended, setRecommended] = useState([]);
  const [becauseYouLiked, setBecauseYouLiked] = useState(null);
  const [topRated, setTopRated] = useState([]);
  const [genres, setGenres] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    Promise.all([
      listMovies({ sort: "trending", limit: 20 }),
      getRecommendations(16),
      getGenres(),
      listMovies({ sort: "rating", limit: 16 }),
      isGuest ? Promise.resolve(null) : getBecauseYouLiked().catch(() => null),
    ])
      .then(([trendingRes, recRes, genreRes, topRatedRes, becauseRes]) => {
        if (cancelled) return;
        setTrending(trendingRes.data);
        setRecommended(recRes.data);
        setGenres(genreRes.data);
        setTopRated(topRatedRes.data);
        if (becauseRes?.data?.anchor) setBecauseYouLiked(becauseRes.data);
      })
      .catch(() => !cancelled && setError("Couldn't load the home page. Is the backend running?"))
      .finally(() => !cancelled && setLoading(false));
    return () => { cancelled = true; };
  }, [isGuest]);

  if (loading) return <LoadingSpinner label="Curating your homepage..." />;

  return (
    <div>
      <ErrorMessage message={error} />
      <HeroCarousel movies={trending.slice(0, 6)} onAddToWatchlist={toggleWatchlist} watchlistIds={watchlistIds} />

      <div className="page-with-panel">
        <div>
          <MovieRow
            title={isGuest ? "Trending Movies" : "Recommended For You"}
            movies={isGuest ? trending : recommended}
            viewAllHref="/discover"
            onAddToWatchlist={toggleWatchlist}
            watchlistIds={watchlistIds}
          />

          {becauseYouLiked && (
            <MovieRow
              title={`Because You Liked "${becauseYouLiked.anchor.title}"`}
              movies={becauseYouLiked.recommendations}
              onAddToWatchlist={toggleWatchlist}
              watchlistIds={watchlistIds}
            />
          )}

          <MovieRow
            title="Trending Movies"
            movies={trending}
            viewAllHref="/discover"
            onAddToWatchlist={toggleWatchlist}
            watchlistIds={watchlistIds}
          />

          <MovieRow
            title="Top Rated Movies"
            movies={topRated}
            viewAllHref="/discover"
            onAddToWatchlist={toggleWatchlist}
            watchlistIds={watchlistIds}
          />

          <div className="section">
            <div className="section-head"><h2>Explore Genres</h2></div>
            <GenreGrid genres={genres} />
          </div>
        </div>

        <RightPanel trending={trending} genres={genres} />
      </div>

      <GuestModal open={guestModalOpen} onClose={() => setGuestModalOpen(false)} />
    </div>
  );
}
