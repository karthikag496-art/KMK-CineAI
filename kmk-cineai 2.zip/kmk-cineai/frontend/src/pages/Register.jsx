import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "../hooks/useAuth";
import { ErrorMessage } from "../components/Feedback";

export default function Register() {
  const [form, setForm] = useState({ username: "", email: "", password: "", confirm: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const { register } = useAuth();
  const navigate = useNavigate();

  function update(key, value) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    if (form.password !== form.confirm) {
      setError("Passwords do not match.");
      return;
    }
    if (form.password.length < 6) {
      setError("Password must be at least 6 characters.");
      return;
    }
    setLoading(true);
    try {
      await register(form.username, form.email, form.password);
      navigate("/onboarding");
    } catch (err) {
      setError(err.response?.data?.detail || "Could not create account.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="auth-shell">
      <div className="auth-visual">
        <div className="bg" style={{ backgroundImage: "url(https://picsum.photos/seed/kmk-register/1200/1600)" }} />
        <div className="scrim" />
        <div className="auth-visual-content">
          <h1 className="hero-title">Join KMK CineAI</h1>
          <p className="hero-desc">Rate movies, build a watchlist, and let our hybrid AI engine learn your taste.</p>
        </div>
      </div>

      <div className="auth-panel">
        <div className="auth-card fade-in">
          <div className="brand">
            <div className="logo-mark">K</div>
            <div className="brand-text">
              <strong>KMK CineAI</strong>
              <span>Better Movies. Smarter Recommendations.</span>
            </div>
          </div>
          <h1>Create Your Account</h1>
          <p className="lead">Find your next favorite movie.</p>

          <ErrorMessage message={error} />

          <form onSubmit={handleSubmit}>
            <div className="field">
              <label>Username</label>
              <input className="input" required value={form.username} onChange={(e) => update("username", e.target.value)} placeholder="moviefan99" />
            </div>
            <div className="field">
              <label>Email</label>
              <input className="input" type="email" required value={form.email} onChange={(e) => update("email", e.target.value)} placeholder="you@example.com" />
            </div>
            <div className="field">
              <label>Password</label>
              <input className="input" type="password" required value={form.password} onChange={(e) => update("password", e.target.value)} placeholder="••••••••" />
            </div>
            <div className="field">
              <label>Confirm Password</label>
              <input className="input" type="password" required value={form.confirm} onChange={(e) => update("confirm", e.target.value)} placeholder="••••••••" />
            </div>
            <button className="btn btn-primary btn-block" type="submit" disabled={loading}>
              {loading ? "Creating account..." : "Create Account"}
            </button>
          </form>

          <div className="auth-footer">
            Already have an account? <Link to="/login">Login</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
