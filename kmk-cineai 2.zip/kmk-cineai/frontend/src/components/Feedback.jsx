export function LoadingSpinner({ label }) {
  return (
    <div className="center-page">
      <div className="spinner" />
      {label && <p className="text-dim">{label}</p>}
    </div>
  );
}

export function ErrorMessage({ message }) {
  if (!message) return null;
  return <div className="error-banner">{message}</div>;
}

export function EmptyState({ title, subtitle }) {
  return (
    <div className="empty-state">
      <h3>{title}</h3>
      <p>{subtitle}</p>
    </div>
  );
}
