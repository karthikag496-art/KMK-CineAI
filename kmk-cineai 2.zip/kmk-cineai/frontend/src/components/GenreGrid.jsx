import { useNavigate } from "react-router-dom";
import { GENRE_EMOJI } from "./Icons";

export default function GenreGrid({ genres, selected = [], onToggle }) {
  const navigate = useNavigate();
  return (
    <div className="genre-grid">
      {genres.map((g) => (
        <div
          key={g}
          className={`genre-card ${selected.includes(g) ? "selected" : ""}`}
          onClick={() => (onToggle ? onToggle(g) : navigate(`/genres/${encodeURIComponent(g)}`))}
        >
          <span className="emoji">{GENRE_EMOJI[g] || "🎬"}</span>
          <span className="name">{g}</span>
        </div>
      ))}
    </div>
  );
}
