import { useNavigate } from "react-router-dom";
import MovieCard from "./MovieCard";

export default function MovieRow({ title, movies, viewAllHref, onAddToWatchlist, watchlistIds }) {
  const navigate = useNavigate();
  if (!movies || movies.length === 0) return null;

  return (
    <div className="section">
      <div className="section-head">
        <h2>{title}</h2>
        {viewAllHref && (
          <span className="view-all" onClick={() => navigate(viewAllHref)} style={{ cursor: "pointer" }}>
            View All →
          </span>
        )}
      </div>
      <div className="movie-row">
        {movies.map((m) => (
          <MovieCard
            key={m.id}
            movie={m}
            onAddToWatchlist={onAddToWatchlist}
            isInWatchlist={watchlistIds?.has(m.id)}
          />
        ))}
      </div>
    </div>
  );
}
