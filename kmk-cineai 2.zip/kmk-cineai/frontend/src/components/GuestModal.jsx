import { useNavigate } from "react-router-dom";

export default function GuestModal({ open, onClose }) {
  const navigate = useNavigate();
  if (!open) return null;

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-card fade-in" onClick={(e) => e.stopPropagation()}>
        <h3>Unlock Personalized Recommendations</h3>
        <p>Create an account to rate movies, build a watchlist, and get recommendations tailored to your taste.</p>
        <div className="modal-actions">
          <button className="btn btn-primary btn-block" onClick={() => navigate("/login")}>Login</button>
          <button className="btn btn-secondary btn-block" onClick={() => navigate("/register")}>Create Account</button>
          <button className="btn btn-ghost btn-block" onClick={onClose}>Continue Browsing</button>
        </div>
      </div>
    </div>
  );
}
