import { useNavigate } from "react-router-dom";
import { StarIcon, PlusIcon, CheckIcon, PlayIcon } from "./Icons";

export default function MovieCard({ movie, onAddToWatchlist, isInWatchlist }) {
  const navigate = useNavigate();
  if (!movie) return null;

  const genres = (movie.genres || "").split(",").filter(Boolean).slice(0, 2);

  return (
    <div className="movie-card fade-in" onClick={() => navigate(`/movie/${movie.id}`)}>
      <div className="poster-wrap">
        <img src={movie.poster_url} alt={movie.title} loading="lazy" />
        {movie.rating > 0 && (
          <div className="rating-badge">
            <StarIcon width={11} height={11} fill="currentColor" />
            {movie.rating.toFixed(1)}
          </div>
        )}
        <div className="hover-overlay" onClick={(e) => e.stopPropagation()}>
          <p>{movie.overview}</p>
          <div className="overlay-actions">
            <button className="btn btn-primary btn-sm" onClick={() => navigate(`/movie/${movie.id}`)}>
              <PlayIcon width={13} height={13} /> Watch
            </button>
            {onAddToWatchlist && (
              <button className="btn btn-ghost btn-sm" onClick={() => onAddToWatchlist(movie)}>
                {isInWatchlist ? <CheckIcon width={13} height={13} /> : <PlusIcon width={13} height={13} />}
              </button>
            )}
          </div>
        </div>
      </div>
      <div className="meta">
        <h4 title={movie.title}>{movie.title}</h4>
        <div className="sub">
          {genres.join(" • ")}{genres.length ? " • " : ""}{movie.release_year}
        </div>
      </div>
    </div>
  );
}
