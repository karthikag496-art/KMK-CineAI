import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { SearchIcon, BellIcon, MenuIcon, UserIcon, LogOutIcon, StarIcon, BookmarkIcon } from "./Icons";
import { useAuth } from "../hooks/useAuth";

export default function Navbar({ onMenuClick }) {
  const [query, setQuery] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const navigate = useNavigate();
  const { user, isGuest, logout } = useAuth();
  const ref = useRef();

  useEffect(() => {
    function handler(e) {
      if (ref.current && !ref.current.contains(e.target)) setMenuOpen(false);
    }
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  function handleSubmit(e) {
    e.preventDefault();
    if (query.trim()) {
      navigate(`/search?q=${encodeURIComponent(query.trim())}`);
    }
  }

  return (
    <header className="navbar">
      <button className="icon-btn mobile-topbar" onClick={onMenuClick}>
        <MenuIcon width={18} height={18} />
      </button>

      <form className="search-bar" onSubmit={handleSubmit} style={{ maxWidth: 480 }}>
        <SearchIcon width={17} height={17} />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search movies, actors, actresses, genres..."
        />
      </form>

      <div className="navbar-actions">
        <button className="icon-btn" title="Notifications">
          <BellIcon width={18} height={18} />
        </button>

        {isGuest ? (
          <div className="flex gap-12">
            <button className="btn btn-ghost btn-sm" onClick={() => navigate("/login")}>Login</button>
            <button className="btn btn-primary btn-sm" onClick={() => navigate("/register")}>Sign Up</button>
          </div>
        ) : (
          <div className="profile-menu-wrap" ref={ref}>
            <button className="profile-avatar" onClick={() => setMenuOpen((o) => !o)}>
              {user.username[0].toUpperCase()}
            </button>
            {menuOpen && (
              <div className="profile-dropdown fade-in">
                <a onClick={() => { navigate("/watchlist"); setMenuOpen(false); }}>
                  <span className="flex items-center gap-8"><BookmarkIcon width={14} height={14}/> Watchlist</span>
                </a>
                <a onClick={() => { navigate("/ratings"); setMenuOpen(false); }}>
                  <span className="flex items-center gap-8"><StarIcon width={14} height={14}/> My Ratings</span>
                </a>
                <a onClick={() => { navigate("/profile"); setMenuOpen(false); }}>
                  <span className="flex items-center gap-8"><UserIcon width={14} height={14}/> Profile</span>
                </a>
                <button onClick={() => { logout(); navigate("/"); setMenuOpen(false); }}>
                  <span className="flex items-center gap-8"><LogOutIcon width={14} height={14}/> Logout</span>
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </header>
  );
}
