import { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { ChevronLeft, ChevronRight, StarIcon, PlayIcon, PlusIcon } from "./Icons";

export default function HeroCarousel({ movies, onAddToWatchlist, watchlistIds }) {
  const [index, setIndex] = useState(0);
  const navigate = useNavigate();

  const next = useCallback(() => setIndex((i) => (i + 1) % movies.length), [movies.length]);
  const prev = () => setIndex((i) => (i - 1 + movies.length) % movies.length);

  useEffect(() => {
    if (!movies.length) return;
    const t = setInterval(next, 7000);
    return () => clearInterval(t);
  }, [next, movies.length]);

  if (!movies || movies.length === 0) return null;
  const movie = movies[index];
  const genres = (movie.genres || "").split(",").filter(Boolean).slice(0, 3);

  return (
    <div className="hero">
      <div className="hero-bg" style={{ backgroundImage: `url(${movie.backdrop_url})` }} />
      <div className="hero-scrim" />
      {movies.length > 1 && (
        <>
          <button className="hero-arrow left" onClick={prev}><ChevronLeft /></button>
          <button className="hero-arrow right" onClick={next}><ChevronRight /></button>
        </>
      )}

      <div className="hero-content fade-in" key={movie.id}>
        <span className="hero-tag">
          {index === 0 ? "#1 Trending" : "Now Streaming"}
        </span>
        <h1 className="hero-title">{movie.title}</h1>
        <div className="hero-meta">
          <span className="rating-pill"><StarIcon width={13} height={13} fill="currentColor" /> {movie.rating.toFixed(1)}/5</span>
          <span>{movie.vote_count} ratings</span>
          <span>{movie.release_year}</span>
          <span>{movie.language}</span>
        </div>
        <div className="hero-genres">
          {genres.map((g) => <span key={g} className="chip outline">{g}</span>)}
        </div>
        <p className="hero-desc">{movie.overview}</p>
        <div className="hero-credits">
          {movie.director && <div><span className="label">Director</span>{movie.director}</div>}
          {movie.cast && <div><span className="label">Cast</span>{movie.cast.split(",").slice(0, 2).join(", ")}</div>}
          {movie.music_director && <div><span className="label">Music Director</span>{movie.music_director}</div>}
        </div>
        <div className="hero-actions">
          <button className="btn btn-primary" onClick={() => navigate(`/movie/${movie.id}`)}>
            <PlayIcon width={15} height={15} /> Watch Now
          </button>
          {onAddToWatchlist && (
            <button className="btn btn-ghost" onClick={() => onAddToWatchlist(movie)}>
              <PlusIcon width={15} height={15} /> {watchlistIds?.has(movie.id) ? "In Watchlist" : "Add to Watchlist"}
            </button>
          )}
        </div>
      </div>

      {movies.length > 1 && (
        <div className="hero-dots">
          {movies.map((m, i) => (
            <button key={m.id} className={i === index ? "active" : ""} onClick={() => setIndex(i)} />
          ))}
        </div>
      )}
    </div>
  );
}
