import { useNavigate } from "react-router-dom";
import { useAuth } from "../hooks/useAuth";

const LANGUAGES = ["Tamil", "English", "Hindi", "Telugu", "Malayalam", "Kannada", "Korean", "Japanese", "Chinese"];
const SORTS = [
  { value: "trending", label: "Trending" },
  { value: "popularity", label: "Popularity" },
  { value: "rating", label: "Highest Rated" },
  { value: "latest", label: "Latest" },
  { value: "az", label: "A-Z" },
];

export function FilterPanel({ filters, setFilters, genres = [] }) {
  const toggle = (key, value) => {
    setFilters((f) => ({ ...f, [key]: f[key] === value ? null : value }));
  };

  return (
    <div className="panel">
      <div className="filter-group">
        <h4>Sort By</h4>
        <div className="filter-chips">
          {SORTS.map((s) => (
            <button
              key={s.value}
              className={`chip ${filters.sort === s.value ? "active" : "outline"}`}
              onClick={() => setFilters((f) => ({ ...f, sort: s.value }))}
            >
              {s.label}
            </button>
          ))}
        </div>
      </div>

      {genres.length > 0 && (
        <div className="filter-group">
          <h4>Genre</h4>
          <div className="filter-chips">
            {genres.map((g) => (
              <button key={g} className={`chip ${filters.genre === g ? "active" : "outline"}`} onClick={() => toggle("genre", g)}>
                {g}
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="filter-group">
        <h4>Language</h4>
        <div className="filter-chips">
          {LANGUAGES.map((l) => (
            <button key={l} className={`chip ${filters.language === l ? "active" : "outline"}`} onClick={() => toggle("language", l)}>
              {l}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

export function RightPanel({ trending, genres, children }) {
  const navigate = useNavigate();
  const { isGuest } = useAuth();

  return (
    <div className="flex-col gap-12">
      {children}

      {isGuest && (
        <div className="panel">
          <h4 style={{ marginBottom: 10, fontSize: 15 }}>Get Personalized Picks</h4>
          <p className="text-dim" style={{ fontSize: 13, marginBottom: 14 }}>
            Login to unlock recommendations tailored to your taste.
          </p>
          <button className="btn btn-primary btn-sm btn-block" onClick={() => navigate("/login")}>Login to Get Personalized Recommendations</button>
        </div>
      )}

      {trending && trending.length > 0 && (
        <div className="panel">
          <h4 style={{ marginBottom: 14, fontSize: 15 }}>Trending Now</h4>
          <div className="flex-col gap-12">
            {trending.slice(0, 5).map((m) => (
              <div key={m.id} className="flex gap-12 items-center" style={{ cursor: "pointer" }} onClick={() => navigate(`/movie/${m.id}`)}>
                <img src={m.poster_url} alt={m.title} style={{ width: 42, height: 60, objectFit: "cover", borderRadius: 6 }} />
                <div>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>{m.title}</div>
                  <div className="text-dim" style={{ fontSize: 11.5 }}>{m.genres?.split(",")[0]} • {m.release_year}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {genres && (
        <div className="panel">
          <h4 style={{ marginBottom: 12, fontSize: 15 }}>Browse Genres</h4>
          <div className="filter-chips">
            {genres.slice(0, 10).map((g) => (
              <button key={g} className="chip outline" onClick={() => navigate(`/genres/${encodeURIComponent(g)}`)}>{g}</button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
