import { NavLink } from "react-router-dom";
import { HomeIcon, CompassIcon, SparklesIcon, BookmarkIcon, StarIcon, GridIcon, XIcon } from "./Icons";
import { GENRE_EMOJI } from "./Icons";

const GENRES = Object.keys(GENRE_EMOJI);

export default function Sidebar({ open, onClose }) {
  return (
    <>
      <div className={`sidebar-drawer-backdrop ${open ? "open" : ""}`} onClick={onClose} />
      <aside className={`sidebar ${open ? "open" : ""}`}>
        <div className="brand">
          <div className="logo-mark">K</div>
          <div className="brand-text">
            <strong>KMK CineAI</strong>
            <span>Karthika • Muthumala • Kowsalya</span>
          </div>
          <button className="icon-btn" style={{ marginLeft: "auto", display: open ? "flex" : "none" }} onClick={onClose}>
            <XIcon width={16} height={16} />
          </button>
        </div>

        <NavLink to="/" end className="nav-link" onClick={onClose}>
          <HomeIcon width={18} height={18} /> Home
        </NavLink>
        <NavLink to="/discover" className="nav-link" onClick={onClose}>
          <CompassIcon width={18} height={18} /> Discover
        </NavLink>
        <NavLink to="/recommendations" className="nav-link" onClick={onClose}>
          <SparklesIcon width={18} height={18} /> Recommendations
        </NavLink>
        <NavLink to="/watchlist" className="nav-link" onClick={onClose}>
          <BookmarkIcon width={18} height={18} /> My Watchlist
        </NavLink>
        <NavLink to="/ratings" className="nav-link" onClick={onClose}>
          <StarIcon width={18} height={18} /> My Ratings
        </NavLink>
        <NavLink to="/discover" className="nav-link" onClick={onClose}>
          <GridIcon width={18} height={18} /> Genres
        </NavLink>

        <div className="sidebar-heading">Explore by Genre</div>
        <div className="genre-nav">
          {GENRES.map((g) => (
            <NavLink key={g} to={`/genres/${encodeURIComponent(g)}`} className="nav-link" onClick={onClose}>
              <span>{GENRE_EMOJI[g]}</span> {g}
            </NavLink>
          ))}
        </div>
      </aside>
    </>
  );
}
