import { useState } from "react";
import { StarIcon } from "./Icons";

/** value is 0-5. If onRate is provided, stars become interactive. */
export default function RatingStars({ value = 0, onRate, size = 20, readonly = false }) {
  const [hover, setHover] = useState(0);
  const display = hover || value;

  return (
    <div className={`stars ${readonly ? "readonly" : ""}`}>
      {[1, 2, 3, 4, 5].map((n) => (
        <button
          key={n}
          type="button"
          className={n <= display ? "filled" : ""}
          disabled={readonly}
          onMouseEnter={() => !readonly && setHover(n)}
          onMouseLeave={() => !readonly && setHover(0)}
          onClick={() => !readonly && onRate && onRate(n)}
          aria-label={`Rate ${n} star`}
        >
          <StarIcon width={size} height={size} fill={n <= display ? "currentColor" : "none"} />
        </button>
      ))}
    </div>
  );
}
