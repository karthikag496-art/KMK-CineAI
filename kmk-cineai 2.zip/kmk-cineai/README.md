# KMK CineAI

**Karthika • Muthumala • Kowsalya**
*Better Movies. Smarter Recommendations.*

A full-stack, AI-powered movie recommendation platform: FastAPI + SQLite backend
with a hybrid recommendation engine (content-based TF-IDF, semantic similarity,
collaborative filtering, and popularity), and a React + Vite frontend styled as
a premium, cinematic streaming-style dashboard.

---

## 1. Features

- **Auth**: JWT-based register/login, guest browsing mode
- **Movies**: browse, search, filter by genre/language/rating, sort by trending/popularity/rating/latest/A-Z
- **Movie details**: full metadata (cast, actresses, director, music director, writer, producer), clickable people pages
- **Ratings**: 1–5 star ratings, stored per user, feeds the recommendation engine
- **Watchlist**: add/remove/view
- **Hybrid AI recommendation engine**:
  - Content-based similarity (TF-IDF + cosine similarity over title/overview/genres/cast/director/language)
  - Semantic similarity (sentence-transformers `all-MiniLM-L6-v2`, with an automatic TF-IDF fallback if that optional dependency isn't installed)
  - Collaborative filtering (SVD over the user–movie rating matrix)
  - Genre/language/actor preference matching
  - Popularity/recency
  - Combined via configurable weights (see `app/services/ranking.py`)
- **Related movies** on every movie page, powered by the same similarity engine (not hard-coded)
- **Onboarding flow** for new users (genre/language preferences) to solve cold start
- **"Because You Liked X"** row for logged-in users
- **Guest mode** with a gating modal on personalized actions (rating, watchlist)
- Responsive, cinematic dark UI using the KMK color palette (see below)

## 2. Tech Stack

- **Frontend**: React 18, Vite, React Router, Axios, plain modern CSS (no UI framework)
- **Backend**: FastAPI, SQLAlchemy, Pydantic, JWT (python-jose), bcrypt
- **Database**: SQLite (swap `DATABASE_URL` for PostgreSQL — the SQLAlchemy models are portable)
- **ML**: scikit-learn (TF-IDF, cosine similarity, TruncatedSVD), optional sentence-transformers

## 3. Color Palette

| Color | Hex | Usage |
|---|---|---|
| Dark Charcoal | `#2F3020` | Background, sidebar, nav |
| Terracotta Orange | `#D96846` | Primary buttons, active nav, ratings |
| Olive Green | `#596235` | Secondary buttons, genre chips |
| Soft Lavender Gray | `#CDCBD6` | Inputs, light surfaces |
| Cream | `#F5F1E8` | Text, headings |

## 4. Folder Structure

```
kmk-cineai/
├── backend/
│   ├── app/
│   │   ├── main.py, database.py, models.py, schemas.py, auth.py
│   │   ├── routers/        auth, movies, recommendations, ratings, watchlist, users
│   │   └── services/       recommender.py (hybrid engine), content_model.py,
│   │                       semantic_model.py, collaborative_model.py, ranking.py
│   ├── ml/                 train_content.py, train_embeddings.py, train_collaborative.py
│   ├── data/                (movies.csv export lands here)
│   ├── movie_data.py        source dataset (46 demo movies)
│   ├── data_loader.py       CSV import/export utility
│   ├── seed.py               seeds DB with movies, demo users, ratings, watchlists
│   ├── requirements.txt
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── components/, pages/, services/api.js, hooks/
│   │   ├── App.jsx, main.jsx, index.css
│   ├── package.json
│   └── index.html
├── README.md
└── docker-compose.yml
```

## 5. Installation & Setup (Windows PowerShell friendly)

### Backend

```powershell
cd backend
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python seed.py
uvicorn app.main:app --reload
```

Backend runs at **http://localhost:8000** — interactive API docs (Swagger) at
**http://localhost:8000/docs**.

Copy `.env.example` to `.env` and edit `SECRET_KEY` before any real deployment.

### Frontend

```powershell
cd frontend
npm install
npm run dev
```

Frontend runs at **http://localhost:5173**.

### macOS / Linux

Same commands, but activate the venv with `source venv/bin/activate`.

## 6. Demo Account

Seeded by `python seed.py`:

| Email | Password |
|---|---|
| demo@kmkcineai.com | Demo@1234 |
| ashwin@kmkcineai.com | Demo@1234 |
| priya@kmkcineai.com | Demo@1234 |

These accounts already have ratings and a watchlist, so recommendations and
collaborative filtering have real signal from the moment you log in. You can
also register a brand-new account to see the onboarding/cold-start flow.

## 7. ML Model Training (optional, offline validation)

The API fits the content, semantic, and collaborative models **in-memory at
request time** (and re-fits automatically whenever a movie or rating changes —
see `HybridRecommender.mark_dirty()` in `app/services/recommender.py`), so
nothing needs to be pre-trained for the app to work. The scripts in `ml/` are
for offline testing/inspection:

```powershell
cd backend
python ml\train_content.py         # prints top-5 similar movies for a sample title
python ml\train_collaborative.py   # fits SVD on current ratings, prints top predictions for one user
python ml\train_embeddings.py      # computes & stores sentence-transformer embeddings (needs optional dep)
```

To enable true semantic embeddings instead of the TF-IDF fallback:

```powershell
pip install sentence-transformers
```

(commented out of `requirements.txt` by default to keep the base install light).

## 8. Loading a Larger Dataset

```powershell
cd backend
python data_loader.py export                 # writes data/movies.csv from movie_data.py
python data_loader.py import data/movies.csv  # or point at your own MovieLens/TMDB-style CSV
```

`data_loader.py` expects the same columns as `movie_data.py` — see `CSV_COLUMNS`
in that file.

## 9. API Documentation

Full interactive documentation (request/response schemas, try-it-out) is
auto-generated by FastAPI at **http://localhost:8000/docs** once the backend
is running. Key endpoints:

```
POST   /auth/register
POST   /auth/login
GET    /auth/me

GET    /movies/
GET    /movies/{id}
GET    /movies/search?q=
GET    /movies/{id}/related
GET    /movies/{id}/recommendations
GET    /genres

GET    /recommendations/                (guest → trending, logged-in → hybrid personalized)
GET    /recommendations/because-you-liked
POST   /recommendations/onboarding

POST   /movies/{id}/rating
DELETE /movies/{id}/rating
GET    /users/me/ratings

POST   /watchlist/{id}
DELETE /watchlist/{id}
GET    /watchlist

GET    /actors/{name}
GET    /actresses/{name}
GET    /directors/{name}
GET    /music-directors/{name}

GET    /health
```

## 10. How the AI Recommendations Work

For a logged-in user, `HybridRecommender.recommend_for_user()`:

1. Pulls the user's rating history. If empty, falls back to their onboarding
   genre/language preferences blended with popularity (cold start).
2. Otherwise builds a **taste profile** by averaging the TF-IDF vectors of
   movies the user rated ≥3.5, and ranks all other movies by cosine similarity
   to that profile (**content score**).
3. Does the same with semantic embeddings of the user's liked movies
   (**semantic score**).
4. Uses a **TruncatedSVD** factorization of the full user–movie rating matrix
   to predict a latent-factor rating for every unseen movie (**collaborative
   score**).
5. Scores genre/language/actor overlap with the user's stated preferences
   (**preference score**).
6. Blends recent + well-rated movies into a **popularity score**.
7. Combines all five with configurable weights (0.30 / 0.25 / 0.25 / 0.10 / 0.10
   by default) into one hybrid score and returns the top-K movies.

**Related movies** on a movie's detail page use the same content + semantic
models, scored against that one movie instead of a user profile — genuinely
computed from cosine similarity over metadata/embeddings, not hard-coded.

## 11. Testing

There's no formal test suite included, but every endpoint was manually
smoke-tested end-to-end during development (auth, search ranking, related
movies, guest vs. personalized recommendations, rating persistence, watchlist
add/remove, and the "because you liked" flow) against the seeded dataset.
Swagger UI at `/docs` is the fastest way to exercise the API directly.

## 12. Troubleshooting

- **`ValueError: password cannot be longer than 72 bytes`** — this is a known
  passlib/bcrypt incompatibility; this project avoids it entirely by calling
  `bcrypt` directly in `app/auth.py`, so it shouldn't occur, but if you're
  pinning a different bcrypt version, keep it below the 5.x line that changed
  its internal API, or keep using the direct-`bcrypt` approach already in place.
- **CORS errors in the browser console** — check `CORS_ORIGINS` in `.env`
  matches the frontend's actual origin (default `http://localhost:5173`).
- **Recommendations look generic** — the hybrid engine needs rating data to
  do more than popularity/preference matching; rate a handful of movies (the
  seeded demo accounts already have ~15–20 ratings each) or run `seed.py` again.
- **Posters look like random photography, not movie art** — poster/backdrop
  URLs point at placeholder images (`picsum.photos`, seeded per movie) since
  no real, licensed poster assets are bundled. Swap `poster_url`/`backdrop_url`
  in `movie_data.py` (or via the admin endpoints) for real, licensed artwork
  before shipping.

## 13. Known Simplifications (for transparency)

This was built as a complete, working demo rather than a production system.
A few corners were deliberately simplified given the scope:

- `GET /movies/{id}/recommendations` currently aliases `related`; a production
  version might diverge it into "users who liked X also liked Y" using pure
  collaborative signal.
- The "admin" movie CRUD endpoints (`/admin/movies/*`) work for any logged-in
  user rather than a role-checked admin — swap in a real role check before
  deploying (see the comment in `app/routers/users.py`).
- No automated test suite (unit/integration tests) is included.
- Posters/backdrops are placeholder images, not licensed movie artwork.
- No FAISS / Neural Collaborative Filtering — SVD via scikit-learn was used
  instead, which is fast and effective at this dataset size; FAISS would only
  start to matter with a catalog several orders of magnitude larger.
